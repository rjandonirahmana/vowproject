//! server/repo.rs — semua query Postgres (tokio-postgres, SQL tulisan tangan).

use anyhow::{Context, Result};
use deadpool_postgres::Pool;
use serde_json::Value;
use tokio_postgres::Row;

use crate::web::fmt::lalu;
use crate::web::model::*;

// ── Statement cache ────────────────────────────────────────────────────────
// Semua query lewat `prepare_cached`: rencana query disiapkan SEKALI per
// koneksi pool lalu dipakai ulang — hemat satu bolak-balik ke Postgres per
// query dibanding mengirim teks SQL (prepare + execute) setiap kali.

type Params<'a> = &'a [&'a (dyn tokio_postgres::types::ToSql + Sync)];
type PgResult<T> = std::result::Result<T, tokio_postgres::Error>;

async fn db_rows(c: &deadpool_postgres::Client, sql: &str, p: Params<'_>) -> PgResult<Vec<Row>> {
    let st = c.prepare_cached(sql).await?;
    c.query(&st, p).await
}

async fn db_row(c: &deadpool_postgres::Client, sql: &str, p: Params<'_>) -> PgResult<Row> {
    let st = c.prepare_cached(sql).await?;
    c.query_one(&st, p).await
}

async fn db_opt(c: &deadpool_postgres::Client, sql: &str, p: Params<'_>) -> PgResult<Option<Row>> {
    let st = c.prepare_cached(sql).await?;
    c.query_opt(&st, p).await
}

async fn db_exec(c: &deadpool_postgres::Client, sql: &str, p: Params<'_>) -> PgResult<u64> {
    let st = c.prepare_cached(sql).await?;
    c.execute(&st, p).await
}

/// Undangan + data internal yang tak boleh dikirim ke tamu.
pub struct InvRow {
    pub id: i64,
    pub inv: Invitation,
    /// SHA-256 kunci Kelola (kunci polos tak pernah disimpan).
    pub manage_key_hash: String,
    pub total_price: i64,
    pub payment_method: String,
    /// WA pemesan (62…) — hanya untuk admin, tak pernah dikirim ke tamu.
    pub contact_phone: String,
    /// Kapan diaktifkan admin (migrasi 044) — dasar masa aktif paket.
    pub activated_at: Option<chrono::DateTime<chrono::Utc>>,
}

fn json<T: serde::de::DeserializeOwned + Default>(v: Value) -> T {
    serde_json::from_value(v).unwrap_or_default()
}

/// Baris dibaca sebagai `to_jsonb(invitations.*)` lalu di-deserialize dengan
/// nilai bawaan: kolom yang belum dimigrasi TIDAK membuat halaman error.
fn row_to_inv(r: &Row) -> InvRow {
    let j: Value = r.get("j");
    let s = |k: &str| j.get(k).and_then(|v| v.as_str()).unwrap_or("").to_string();
    InvRow {
        id: j.get("id").and_then(|v| v.as_i64()).unwrap_or(0),
        manage_key_hash: s("manage_key_hash"),
        total_price: j.get("total_price").and_then(|v| v.as_i64()).unwrap_or(0),
        payment_method: s("payment_method"),
        contact_phone: s("contact_phone"),
        activated_at: j.get("activated_at").and_then(|v| v.as_str()).and_then(|t| chrono::DateTime::parse_from_rfc3339(t).ok()).map(|t| t.with_timezone(&chrono::Utc)),
        inv: serde_json::from_value(j.clone()).unwrap_or_default(),
    }
}

pub async fn invitation(pool: &Pool, slug: &str) -> Result<Option<InvRow>> {
    let c = pool.get().await?;
    let sql = "SELECT to_jsonb(i) AS j FROM invitations i WHERE slug = $1 AND status <> 'nonaktif'";
    Ok(db_opt(&c,sql, &[&slug]).await?.as_ref().map(row_to_inv))
}

pub async fn demo_invitation(pool: &Pool) -> Result<Option<InvRow>> {
    let c = pool.get().await?;
    let sql = "SELECT to_jsonb(i) AS j FROM invitations i WHERE is_demo ORDER BY id LIMIT 1";
    Ok(db_opt(&c,sql, &[]).await?.as_ref().map(row_to_inv))
}

/// Slug sudah dipakai undangan mana pun (termasuk nonaktif) — dicek SEBELUM
/// unggah, karena folder RustFS foto/{slug}/ & musik/{slug}/ ikut slug.
/// Kandidat slug PERTAMA yang belum dipakai — semua dicek dalam SATU query
/// (`= ANY`), bukan satu query per kandidat di dalam loop.
pub async fn first_free_slug(pool: &Pool, candidates: &[String]) -> Result<Option<String>> {
    let c = pool.get().await?;
    let taken: std::collections::HashSet<String> = db_rows(&c, "SELECT slug FROM invitations WHERE slug = ANY($1)", &[&candidates])
        .await?
        .iter()
        .map(|r| r.get(0))
        .collect();
    Ok(candidates.iter().find(|s| !taken.contains(*s)).cloned())
}

/// Pelanggaran UNIQUE (kode 23505) — mis. slug direbut pemesan lain.
pub fn is_unique_violation(e: &anyhow::Error) -> bool {
    e.chain()
        .filter_map(|c| c.downcast_ref::<tokio_postgres::Error>())
        .any(|pe| pe.code() == Some(&tokio_postgres::error::SqlState::UNIQUE_VIOLATION))
}

/// Tamu terdaftar via kode link pribadi; sekaligus mencatat waktu buka pertama.
pub async fn open_guest(pool: &Pool, inv_id: i64, code: &str) -> Result<Option<(i64, GuestInfo)>> {
    let c = pool.get().await?;
    let row = db_opt(&c,
        
            "UPDATE guests SET opened_at = COALESCE(opened_at, NOW())
             WHERE invitation_id = $1 AND code = $2
             RETURNING id, code, name, category, session, table_no, pax",
            &[&inv_id, &code.to_uppercase()],
        )
        .await?;
    Ok(row.map(|r| {
        (
            r.get("id"),
            GuestInfo {
                code: r.get("code"),
                name: r.get("name"),
                category: r.get("category"),
                session: r.get("session"),
                table_no: r.get("table_no"),
                pax: r.get("pax"),
            },
        )
    }))
}

pub async fn guest_id(pool: &Pool, inv_id: i64, code: &str) -> Result<Option<i64>> {
    let c = pool.get().await?;
    Ok(db_opt(&c,"SELECT id FROM guests WHERE invitation_id = $1 AND code = $2", &[&inv_id, &code.to_uppercase()])
        .await?
        .map(|r| r.get(0)))
}

pub async fn wishes(pool: &Pool, inv_id: i64, limit: i64) -> Result<WishPage> {
    let c = pool.get().await?;
    let total: i64 = db_row(&c,
        "SELECT COUNT(*) FROM rsvps WHERE invitation_id = $1 AND message <> ''", &[&inv_id])
        .await?
        .get(0);
    let rows = db_rows(&c,
        
            "SELECT name, status, message, EXTRACT(EPOCH FROM NOW() - created_at)::BIGINT AS age
             FROM rsvps WHERE invitation_id = $1 AND message <> ''
             ORDER BY created_at DESC LIMIT $2",
            &[&inv_id, &limit],
        )
        .await?;
    Ok(WishPage {
        total,
        items: rows
            .iter()
            .map(|r| Wish {
                name: r.get("name"),
                status: r.get("status"),
                message: r.get("message"),
                ago: lalu(r.get("age")),
                age: r.get("age"),
            })
            .collect(),
    })
}

pub struct NewRsvp<'a> {
    pub inv_id: i64,
    pub guest_id: Option<i64>,
    pub name: &'a str,
    pub phone: &'a str,
    pub status: &'a str,
    pub pax: i32,
    pub session: &'a str,
    pub message: &'a str,
}

/// `true` = baris baru; `false` = RSVP tamu terdaftar yang sudah ada diperbarui.
pub async fn upsert_rsvp(pool: &Pool, n: NewRsvp<'_>) -> Result<bool> {
    let c = pool.get().await?;
    match n.guest_id {
        // Tamu terdaftar: satu RSVP per tamu, kirim ulang = perbarui.
        // xmax = 0 hanya pada baris yang baru di-INSERT.
        Some(gid) => {
            Ok(db_row(&c,
                "INSERT INTO rsvps (invitation_id, guest_id, name, phone, status, pax, session, message)
                 VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
                 ON CONFLICT (guest_id) WHERE guest_id IS NOT NULL DO UPDATE SET
                   name = EXCLUDED.name, phone = EXCLUDED.phone, status = EXCLUDED.status,
                   pax = EXCLUDED.pax, session = EXCLUDED.session,
                   message = CASE WHEN EXCLUDED.message = '' THEN rsvps.message ELSE EXCLUDED.message END,
                   created_at = NOW()
                 RETURNING (xmax = 0)",
                &[&n.inv_id, &gid, &n.name, &n.phone, &n.status, &n.pax, &n.session, &n.message],
            )
            .await?
            .get(0))
        }
        None => {
            db_exec(&c,
                "INSERT INTO rsvps (invitation_id, name, phone, status, pax, session, message)
                 VALUES ($1,$2,$3,$4,$5,$6,$7)",
                &[&n.inv_id, &n.name, &n.phone, &n.status, &n.pax, &n.session, &n.message],
            )
            .await?;
            Ok(true)
        }
    }
}

/// Jumlah ucapan (RSVP bermesej) sebenarnya di DB.
pub async fn wish_total(pool: &Pool, inv_id: i64) -> Result<i64> {
    let c = pool.get().await?;
    Ok(db_row(&c, "SELECT COUNT(*) FROM rsvps WHERE invitation_id = $1 AND message <> ''", &[&inv_id]).await?.get(0))
}

pub async fn insert_gift(
    pool: &Pool,
    inv_id: i64,
    guest_id: Option<i64>,
    name: &str,
    amount: i64,
    channel: &str,
    note: &str,
) -> Result<()> {
    let c = pool.get().await?;
    db_exec(&c,
        "INSERT INTO gifts (invitation_id, guest_id, name, amount, channel, note) VALUES ($1,$2,$3,$4,$5,$6)",
        &[&inv_id, &guest_id, &name, &amount, &channel, &note],
    )
    .await?;
    Ok(())
}

// ── Dashboard pengantin ────────────────────────────────────────────────────

pub async fn guests(pool: &Pool, inv_id: i64) -> Result<Vec<GuestRow>> {
    let c = pool.get().await?;
    let rows = db_rows(&c,
        
            "SELECT g.code, g.name, g.phone, g.category, g.session, g.table_no, g.pax,
                    g.opened_at IS NOT NULL AS opened, g.checked_in_at IS NOT NULL AS checked_in,
                    EXTRACT(EPOCH FROM NOW() - g.sent_at)::BIGINT AS sent_age,
                    COALESCE(r.status, '') AS rsvp, COALESCE(r.pax, 0) AS rsvp_pax,
                    COALESCE((SELECT SUM(amount) FROM gifts WHERE guest_id = g.id), 0)::BIGINT AS gift
             FROM guests g
             LEFT JOIN rsvps r ON r.guest_id = g.id
             WHERE g.invitation_id = $1
             ORDER BY g.created_at DESC, g.id DESC
             -- Batas aman: dashboard memuat seluruh daftar ke memori (server & WASM).
             LIMIT 5000",
            &[&inv_id],
        )
        .await?;
    Ok(rows
        .iter()
        .map(|r| GuestRow {
            code: r.get("code"),
            name: r.get("name"),
            phone: r.get("phone"),
            category: r.get("category"),
            session: r.get("session"),
            table_no: r.get("table_no"),
            pax: r.get("pax"),
            rsvp: r.get("rsvp"),
            rsvp_pax: r.get("rsvp_pax"),
            opened: r.get("opened"),
            checked_in: r.get("checked_in"),
            sent_ago: r.get::<_, Option<i64>>("sent_age").map(lalu).unwrap_or_default(),
            gift_amount: r.get("gift"),
        })
        .collect())
}

pub async fn stats(pool: &Pool, inv_id: i64) -> Result<Stats> {
    let c = pool.get().await?;
    let r = db_row(&c,
        
            // Satu pindaian per tabel (agregat FILTER), bukan 11 subquery.
            "SELECT g.*, r.*, f.* FROM
               (SELECT COUNT(*) AS total_guests, COALESCE(SUM(pax),0)::BIGINT AS total_pax,
                       COUNT(*) FILTER (WHERE sent_at IS NOT NULL) AS sent,
                       COUNT(*) FILTER (WHERE checked_in_at IS NOT NULL) AS checked_in
                  FROM guests WHERE invitation_id = $1) g,
               (SELECT COUNT(*) AS rsvp_count,
                       COUNT(*) FILTER (WHERE status = 'hadir') AS hadir_count,
                       COALESCE(SUM(pax) FILTER (WHERE status = 'hadir'),0)::BIGINT AS hadir_pax,
                       COUNT(*) FILTER (WHERE status = 'ragu') AS ragu_count,
                       COUNT(*) FILTER (WHERE status = 'tidak') AS tidak_count
                  FROM rsvps WHERE invitation_id = $1) r,
               (SELECT COALESCE(SUM(amount),0)::BIGINT AS gift_total, COUNT(*) AS gift_count
                  FROM gifts WHERE invitation_id = $1) f",
            &[&inv_id],
        )
        .await?;
    Ok(Stats {
        total_guests: r.get("total_guests"),
        total_pax: r.get("total_pax"),
        sent: r.get("sent"),
        checked_in: r.get("checked_in"),
        rsvp_count: r.get("rsvp_count"),
        hadir_count: r.get("hadir_count"),
        hadir_pax: r.get("hadir_pax"),
        ragu_count: r.get("ragu_count"),
        tidak_count: r.get("tidak_count"),
        gift_total: r.get("gift_total"),
        gift_count: r.get("gift_count"),
    })
}

/// Umpan aktivitas: RSVP, undangan dibuka, tanda kasih — 8 terbaru.
pub async fn activity(pool: &Pool, inv_id: i64) -> Result<Vec<Activity>> {
    let c = pool.get().await?;
    let rows = db_rows(&c,
        
            "SELECT kind, name, status, pax, amount, EXTRACT(EPOCH FROM NOW() - at)::BIGINT AS age FROM (
               SELECT 'rsvp' AS kind, name, status, pax, 0::BIGINT AS amount, created_at AS at
                 FROM rsvps WHERE invitation_id = $1
               UNION ALL
               SELECT 'open', name, '', 0, 0, opened_at FROM guests
                 WHERE invitation_id = $1 AND opened_at IS NOT NULL
               UNION ALL
               SELECT 'gift', name, '', 0, amount, created_at FROM gifts WHERE invitation_id = $1
             ) a ORDER BY at DESC LIMIT 8",
            &[&inv_id],
        )
        .await?;
    Ok(rows
        .iter()
        .map(|r| {
            let name: String = r.get("name");
            let text = match r.get::<_, &str>("kind") {
                "rsvp" => match r.get::<_, &str>("status") {
                    "hadir" => format!("{name} mengonfirmasi hadir ({} orang) dan mengirimkan doa restu.", r.get::<_, i32>("pax")),
                    "ragu" => format!("{name} masih ragu untuk hadir."),
                    _ => format!("{name} berhalangan hadir dan mengirim doa restu."),
                },
                "open" => format!("{name} membuka undangan digital dari tautan pribadinya."),
                _ => format!("{name} melaporkan tanda kasih {}.", crate::web::fmt::rupiah(r.get("amount"))),
            };
            Activity { text, ago: lalu(r.get("age")) }
        })
        .collect())
}

pub struct NewGuest<'a> {
    pub name: &'a str,
    pub phone: &'a str,
    pub category: &'a str,
    pub session: &'a str,
    pub table_no: &'a str,
    pub pax: i32,
}

/// Kode 6 karakter tanpa huruf/angka yang mirip (0/O, 1/I).
pub fn new_code() -> String {
    super::auth::random_chars(b"ABCDEFGHJKLMNPQRSTUVWXYZ23456789", 6)
}

pub async fn add_guest(pool: &Pool, inv_id: i64, g: NewGuest<'_>) -> Result<String> {
    let c = pool.get().await?;
    for _ in 0..5 {
        let code = new_code();
        let n = db_exec(&c,
            
                "INSERT INTO guests (invitation_id, code, name, phone, category, session, table_no, pax)
                 VALUES ($1,$2,$3,$4,$5,$6,$7,$8) ON CONFLICT (code) DO NOTHING",
                &[&inv_id, &code, &g.name, &g.phone, &g.category, &g.session, &g.table_no, &g.pax],
            )
            .await?;
        if n == 1 {
            return Ok(code);
        }
    }
    anyhow::bail!("gagal membuat kode tamu unik")
}

pub async fn delete_guest(pool: &Pool, inv_id: i64, code: &str) -> Result<()> {
    let c = pool.get().await?;
    db_exec(&c,"DELETE FROM guests WHERE invitation_id = $1 AND code = $2", &[&inv_id, &code]).await?;
    Ok(())
}

pub async fn mark_sent(pool: &Pool, inv_id: i64, code: &str) -> Result<()> {
    let c = pool.get().await?;
    db_exec(&c,"UPDATE guests SET sent_at = NOW() WHERE invitation_id = $1 AND code = $2", &[&inv_id, &code]).await?;
    Ok(())
}

/// Check-in QR. Mengembalikan (nama, sudah check-in sebelumnya?).
pub async fn check_in(pool: &Pool, inv_id: i64, code: &str) -> Result<Option<(String, bool)>> {
    let c = pool.get().await?;
    let code = code.trim().to_uppercase();
    // Hanya baris yang BELUM check-in yang diubah: dua pemindaian bersamaan →
    // tepat satu yang mendapat "baru", sisanya "sudah".
    if let Some(r) = db_opt(&c,
        
            "UPDATE guests SET checked_in_at = NOW()
             WHERE invitation_id = $1 AND code = $2 AND checked_in_at IS NULL
             RETURNING name",
            &[&inv_id, &code],
        )
        .await?
    {
        return Ok(Some((r.get(0), false)));
    }
    let r = db_opt(&c,"SELECT name FROM guests WHERE invitation_id = $1 AND code = $2", &[&inv_id, &code]).await?;
    Ok(r.map(|r| (r.get(0), true)))
}

// ── Checkout ───────────────────────────────────────────────────────────────

/// Data satu mempelai dari formulir pesan.
pub struct MempelaiInput {
    pub name: String,
    pub degree: String,
    pub nick: String,
    pub parents: String,
    pub ig: String,
    pub photo: String,
}

pub struct NewInvitation {
    pub slug: String,
    pub manage_key_hash: String,
    pub theme: String,
    pub package: String,
    pub bride: MempelaiInput,
    pub groom: MempelaiInput,
    pub events: Value,
    pub dress_code: String,
    pub quote_text: String,
    pub quote_source: String,
    pub music_title: String,
    pub music_artist: String,
    pub music_url: String,
    pub music_autoplay: bool,
    pub banks: Value,
    pub family_name: String,
    pub addons: Value,
    pub coupon: String,
    pub total_price: i64,
    pub payment_method: String,
    pub contact_phone: String,
    pub cover_photo: String,
    pub love_story: Value,
    pub live_url: String,
    pub gallery: Value,
    pub dress_colors: Value,
    pub lang: String,
}

/// Sunting isi undangan oleh pemilik/admin (/kelola/{slug}/sunting). Paket,
/// add-on, kupon, total & metode bayar TIDAK ikut (sudah dihitung saat pesan).
pub async fn update_invitation_isi(pool: &Pool, id: i64, n: &NewInvitation) -> Result<()> {
    let c = pool.get().await?;
    let (b, g) = (&n.bride, &n.groom);
    db_exec(&c,
        "UPDATE invitations SET theme = $2,
            bride_name = $3, bride_degree = $4, bride_nick = $5, bride_parents = $6, bride_ig = $7, bride_photo = $8,
            groom_name = $9, groom_degree = $10, groom_nick = $11, groom_parents = $12, groom_ig = $13, groom_photo = $14,
            events = $15, dress_code = $16, quote_text = $17, quote_source = $18,
            music_title = $19, music_artist = $20, music_url = $21, music_autoplay = $22,
            banks = $23, family_name = $24, contact_phone = $25, cover_photo = $26,
            love_story = $27, live_url = $28, gallery = $29, dress_colors = $30, lang = $31, updated_at = NOW()
          WHERE id = $1 AND NOT is_demo",
        &[
            &id, &n.theme,
            &b.name, &b.degree, &b.nick, &b.parents, &b.ig, &b.photo,
            &g.name, &g.degree, &g.nick, &g.parents, &g.ig, &g.photo,
            &n.events, &n.dress_code, &n.quote_text, &n.quote_source,
            &n.music_title, &n.music_artist, &n.music_url, &n.music_autoplay,
            &n.banks, &n.family_name, &n.contact_phone, &n.cover_photo,
            &n.love_story, &n.live_url, &n.gallery, &n.dress_colors, &n.lang,
        ],
    )
    .await
    .context("sunting undangan")?;
    Ok(())
}

/// Simpan URL video prewedding. `Ok(false)` = kolom belum ada (migrasi 022
/// belum dijalankan) → pemanggil membuang unggahannya.
pub async fn set_invitation_video(pool: &Pool, slug: &str, url: &str) -> Result<bool> {
    let c = pool.get().await?;
    match db_exec(&c, "UPDATE invitations SET video_url = $2 WHERE slug = $1", &[&slug, &url]).await {
        Ok(_) => Ok(true),
        Err(e) if e.code() == Some(&tokio_postgres::error::SqlState::UNDEFINED_COLUMN) => Ok(false),
        Err(e) => Err(anyhow::Error::new(e).context("simpan video")),
    }
}

pub async fn create_invitation(pool: &Pool, n: &NewInvitation) -> Result<()> {
    let c = pool.get().await?;
    let (b, g) = (&n.bride, &n.groom);
    db_exec(&c,
        "INSERT INTO invitations (
            slug, manage_key_hash, theme, package,
            bride_name, bride_degree, bride_nick, bride_parents, bride_ig, bride_photo,
            groom_name, groom_degree, groom_nick, groom_parents, groom_ig, groom_photo,
            events, dress_code, quote_text, quote_source,
            music_title, music_artist, music_url, music_autoplay,
            banks, family_name, addons, coupon, total_price, payment_method, contact_phone,
            cover_photo, love_story, live_url, gallery, dress_colors, lang
         ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,
                   $21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37)",
        &[
            &n.slug, &n.manage_key_hash, &n.theme, &n.package,
            &b.name, &b.degree, &b.nick, &b.parents, &b.ig, &b.photo,
            &g.name, &g.degree, &g.nick, &g.parents, &g.ig, &g.photo,
            &n.events, &n.dress_code, &n.quote_text, &n.quote_source,
            &n.music_title, &n.music_artist, &n.music_url, &n.music_autoplay,
            &n.banks, &n.family_name, &n.addons, &n.coupon, &n.total_price, &n.payment_method, &n.contact_phone,
            &n.cover_photo, &n.love_story, &n.live_url, &n.gallery, &n.dress_colors, &n.lang,
        ],
    )
    .await
    .context("insert invitation")?;
    Ok(())
}

// ── Tema (katalog di DB) ───────────────────────────────────────────────────

pub async fn themes(pool: &Pool) -> Result<Vec<crate::web::skin::ThemeInfo>> {
    let c = pool.get().await?;
    // to_jsonb: kolom tema yang belum dimigrasi → nilai bawaan, bukan error.
    let rows = db_rows(&c,
        
            "SELECT to_jsonb(t) || jsonb_build_object('created', EXTRACT(EPOCH FROM created_at)::BIGINT) AS j
             FROM themes t ORDER BY sort_order, created_at",
            &[],
        )
        .await
        .context("select themes")?;
    Ok(rows.iter().filter_map(|r| serde_json::from_value(r.get::<_, Value>("j")).ok()).collect())
}

/// Kolom tema yang disimpan dari editor admin — SATU daftar untuk INSERT dan
/// UPDATE. Nilai diambil per NAMA dari JSON `ThemeInfo` lewat
/// `jsonb_populate_record` (tak ada lagi 31 parameter posisional yang bisa
/// tertukar urutannya saat kolom bertambah).
const THEME_COLS: &[&str] = &[
    "slug", "name", "category", "nuansa", "palette", "region", "description", "tags", "badge", "rating", "reviews",
    "layout", "ornament", "font", "tokens", "dark", "image_url", "image_mode", "listed", "sort_order",
    "script_font", "bg_image", "frame_image", "card_deco", "float_deco", "open_anim", "page_mode", "scroll_anim",
    "gerak_judul", "gerak_foto", "ken_burns", "bg_video", "open_video", "rupa",
];
/// Kolom dari migrasi yang mungkin belum dijalankan (022, 033) — upsert diulang
/// tanpa kolom ini bila DB belum punya (admin tetap bisa menyimpan tema).
const THEME_COLS_NEW: &[&str] = &["bg_video", "open_video", "rupa"];

fn upsert_theme_sql(with_new: bool) -> &'static str {
    static FULL: std::sync::OnceLock<String> = std::sync::OnceLock::new();
    static OLD: std::sync::OnceLock<String> = std::sync::OnceLock::new();
    (if with_new { &FULL } else { &OLD }).get_or_init(|| {
        let cols: Vec<&str> = THEME_COLS.iter().copied().filter(|c| with_new || !THEME_COLS_NEW.contains(c)).collect();
        let set: Vec<String> = cols.iter().filter(|c| **c != "slug").map(|c| format!("{c} = EXCLUDED.{c}")).collect();
        let cols = cols.join(", ");
        format!(
            "INSERT INTO themes ({cols}) SELECT {cols} FROM jsonb_populate_record(NULL::themes, $1)
             ON CONFLICT (slug) DO UPDATE SET {}, updated_at = NOW()",
            set.join(", ")
        )
    })
}

/// Galat "kolom belum ada" (migrasi 017b belum dijalankan) → diabaikan.
fn ignore_missing_column(r: PgResult<u64>, what: &str) -> Result<()> {
    match r {
        Ok(_) => Ok(()),
        Err(e) if e.code() == Some(&tokio_postgres::error::SqlState::UNDEFINED_COLUMN) => Ok(()),
        Err(e) => Err(anyhow::Error::new(e).context(what.to_string())),
    }
}

pub async fn upsert_theme(pool: &Pool, t: &crate::web::skin::ThemeInfo) -> Result<()> {
    let c = pool.get().await?;
    // Admin mengubah gerak tema → kunci, agar migrasi seed berikutnya tak
    // menimpanya (017b). Dicek SEBELUM upsert (membandingkan nilai lama).
    ignore_missing_column(
        db_exec(&c,
            "UPDATE themes SET motion_locked = TRUE
              WHERE slug = $1 AND NOT motion_locked
                AND (open_anim, scroll_anim, float_deco, gerak_judul, gerak_foto, ken_burns)
                    IS DISTINCT FROM ($2, $3, $4, $5, $6, $7)",
            &[&t.slug, &t.open_anim, &t.scroll_anim, &t.float_deco, &t.gerak_judul, &t.gerak_foto, &t.ken_burns],
        )
        .await,
        "kunci gerak tema",
    )?;
    let json = serde_json::to_value(t)?;
    match db_exec(&c, upsert_theme_sql(true), &[&json]).await {
        Err(e) if e.code() == Some(&tokio_postgres::error::SqlState::UNDEFINED_COLUMN) => {
            db_exec(&c, upsert_theme_sql(false), &[&json]).await.context("upsert theme")?;
        }
        r => {
            r.context("upsert theme")?;
        }
    }
    Ok(())
}

pub async fn theme_exists(pool: &Pool, slug: &str) -> Result<bool> {
    let c = pool.get().await?;
    Ok(db_opt(&c,"SELECT 1 FROM themes WHERE slug = $1", &[&slug]).await?.is_some())
}

/// slug → jumlah undangan yang memakai tema itu.
pub async fn theme_usage(pool: &Pool) -> Result<std::collections::HashMap<String, i64>> {
    let c = pool.get().await?;
    let rows = db_rows(&c,"SELECT theme, COUNT(*) AS n FROM invitations GROUP BY theme", &[]).await?;
    Ok(rows.iter().map(|r| (r.get("theme"), r.get("n"))).collect())
}

/// Hapus tema yang belum dipakai undangan mana pun. `false` = masih dipakai
/// (termasuk bila checkout bersamaan memakainya — dijaga FK migrasi 004).
pub async fn delete_theme(pool: &Pool, slug: &str) -> Result<bool> {
    let c = pool.get().await?;
    match db_exec(&c,
        
            "DELETE FROM themes WHERE slug = $1 AND NOT EXISTS (SELECT 1 FROM invitations WHERE theme = $1)",
            &[&slug],
        )
        .await
    {
        Ok(n) => Ok(n > 0),
        Err(e) if e.code() == Some(&tokio_postgres::error::SqlState::FOREIGN_KEY_VIOLATION) => Ok(false),
        Err(e) => Err(e.into()),
    }
}

/// Ganti kunci Kelola (kunci lama langsung tak berlaku). Demo tak bisa.
pub async fn reset_manage_key(pool: &Pool, slug: &str, hash: &str) -> Result<bool> {
    let c = pool.get().await?;
    let n = db_exec(&c,
        "UPDATE invitations SET manage_key_hash = $2, updated_at = NOW() WHERE slug = $1 AND NOT is_demo", &[&slug, &hash])
        .await?;
    Ok(n > 0)
}

// ── Admin: pesanan ─────────────────────────────────────────────────────────

pub async fn admin_invitations(pool: &Pool, q: &str, ttl_hours: i64) -> Result<Vec<AdminInv>> {
    let c = pool.get().await?;
    // $1 = kata kunci apa adanya (kosong = semua), $3 = pola ILIKE yang aman.
    let q = q.replace(['%', '_'], "");
    let like = format!("%{q}%");
    let rows = db_rows(&c,
        
            "SELECT slug, bride_name, groom_name, theme, package, status, total_price, payment_method,
                    contact_phone, is_demo, to_char(created_at AT TIME ZONE 'Asia/Jakarta', 'YYYY-MM-DD HH24:MI') AS created,
                    -- Kolom bukti (017) dibaca lewat jsonb: belum dimigrasi → kosong, bukan galat.
                    COALESCE(to_jsonb(i) ->> 'payment_proof', '') AS payment_proof,
                    to_char((to_jsonb(i) ->> 'payment_proof_at')::timestamptz AT TIME ZONE 'Asia/Jakarta', 'YYYY-MM-DD HH24:MI') AS proof_at,
                    CASE WHEN status = 'menunggu_pembayaran' AND NOT is_demo AND to_jsonb(i) ->> 'payment_proof_at' IS NULL
                         THEN GREATEST(0, EXTRACT(EPOCH FROM (created_at + make_interval(hours => $2::int) - NOW())) / 60)::BIGINT
                    END AS minutes_left
             FROM invitations i
             WHERE $1 = '' OR slug ILIKE $3 OR bride_name ILIKE $3 OR groom_name ILIKE $3 OR contact_phone ILIKE $3
             ORDER BY (status = 'menunggu_pembayaran' AND to_jsonb(i) ->> 'payment_proof_at' IS NOT NULL) DESC,
                      (status = 'menunggu_pembayaran') DESC, created_at DESC
             LIMIT 200",
            &[&q, &(ttl_hours as i32), &like],
        )
        .await
        .context("admin invitations")?;
    Ok(rows
        .iter()
        .map(|r| AdminInv {
            slug: r.get("slug"),
            package_name: String::new(),
            couple: format!("{} & {}", r.get::<_, String>("bride_name"), r.get::<_, String>("groom_name")),
            theme: r.get("theme"),
            package: r.get("package"),
            status: r.get("status"),
            total_price: r.get("total_price"),
            payment_method: r.get("payment_method"),
            contact_phone: r.get("contact_phone"),
            is_demo: r.get("is_demo"),
            created: r.get("created"),
            minutes_left: r.get("minutes_left"),
            payment_proof: r.get("payment_proof"),
            proof_at: r.get::<_, Option<String>>("proof_at").unwrap_or_default(),
        })
        .collect())
}

/// Bukti transfer pemesan: (URL gambar, "x menit lalu"). Belum ada → None.
/// Kolom belum dimigrasi (017) → Err; pemanggil memperlakukannya "belum ada".
pub async fn payment_proof(pool: &Pool, inv_id: i64) -> Result<Option<(String, String)>> {
    let c = pool.get().await?;
    let r = db_opt(&c,
        "SELECT payment_proof, EXTRACT(EPOCH FROM NOW() - payment_proof_at)::BIGINT AS age
           FROM invitations WHERE id = $1 AND payment_proof_at IS NOT NULL",
        &[&inv_id],
    )
    .await?;
    Ok(r.map(|r| (r.get("payment_proof"), lalu(r.get("age")))))
}

/// Simpan bukti transfer (hanya pesanan yang masih menunggu pembayaran).
/// Mengembalikan URL bukti LAMA (untuk dihapus dari RustFS) bila diganti;
/// `None` = undangan tak ditemukan / sudah tidak menunggu pembayaran.
pub async fn set_payment_proof(pool: &Pool, inv_id: i64, url: &str) -> Result<Option<String>> {
    let c = pool.get().await?;
    let r = db_opt(&c,
        "UPDATE invitations i SET payment_proof = $2, payment_proof_at = NOW(), updated_at = NOW()
           FROM (SELECT id, payment_proof AS lama FROM invitations WHERE id = $1 FOR UPDATE) o
          WHERE i.id = o.id AND i.status = 'menunggu_pembayaran' AND NOT i.is_demo
          RETURNING o.lama",
        &[&inv_id, &url],
    )
    .await?;
    Ok(r.map(|r| r.get(0)))
}

/// Hasil ubah status oleh admin — cukup untuk memberi tahu pemesan.
pub struct StatusBerubah {
    /// Status SEBELUM diubah (baris dikunci → dua admin serentak tak sama-sama
    /// melihat "menunggu" lalu sama-sama mengirim WA "aktif").
    pub lama: String,
    pub contact_phone: String,
    pub couple: String,
}

/// `None` = tak ditemukan / undangan demo.
pub async fn admin_update_invitation(pool: &Pool, slug: &str, status: &str, theme: &str) -> Result<Option<StatusBerubah>> {
    let c = pool.get().await?;
    // Pertama kali aktif → catat activated_at (dasar masa aktif paket);
    // diaktifkan ulang setelah nonaktif → tanggal awal tetap.
    let baru = db_opt(&c,
        "UPDATE invitations i SET status = $2, theme = $3, updated_at = NOW(),
                activated_at = CASE WHEN $2 = 'aktif' THEN COALESCE(i.activated_at, NOW()) ELSE i.activated_at END
           FROM (SELECT id, status AS lama FROM invitations WHERE slug = $1 AND NOT is_demo FOR UPDATE) o
          WHERE i.id = o.id
          RETURNING o.lama, i.contact_phone, i.bride_name, i.groom_name",
        &[&slug, &status, &theme],
    )
    .await;
    // Migrasi 044 belum jalan (kolom absen) → tetap bisa mengubah status.
    let r = match baru {
        Err(e) if format!("{e:#}").contains("activated_at") => db_opt(&c,
            "UPDATE invitations i SET status = $2, theme = $3, updated_at = NOW()
               FROM (SELECT id, status AS lama FROM invitations WHERE slug = $1 AND NOT is_demo FOR UPDATE) o
              WHERE i.id = o.id
              RETURNING o.lama, i.contact_phone, i.bride_name, i.groom_name",
            &[&slug, &status, &theme],
        )
        .await?,
        r => r?,
    };
    Ok(r.map(|r| StatusBerubah {
        lama: r.get("lama"),
        contact_phone: r.get("contact_phone"),
        couple: format!("{} & {}", r.get::<_, String>("bride_name"), r.get::<_, String>("groom_name")),
    }))
}

// ── Konten situs (site_content) ────────────────────────────────────────────

pub async fn content_rows(pool: &Pool) -> Result<Vec<(String, Value)>> {
    let c = pool.get().await?;
    let rows = db_rows(&c,"SELECT key, data FROM site_content", &[]).await.context("select site_content")?;
    Ok(rows.iter().map(|r| (r.get("key"), r.get("data"))).collect())
}

pub async fn save_content(pool: &Pool, key: &str, data: &Value, by: &str) -> Result<()> {
    let c = pool.get().await?;
    db_exec(&c,
        "INSERT INTO site_content (key, data, updated_by) VALUES ($1, $2, $3)
         ON CONFLICT (key) DO UPDATE SET data = EXCLUDED.data, updated_by = EXCLUDED.updated_by, updated_at = NOW()",
        &[&key, data, &by],
    )
    .await
    .context("save site_content")?;
    Ok(())
}

/// kunci → "nama • 2026-09-30 14:05" (siapa & kapan terakhir disunting).
pub async fn content_meta(pool: &Pool) -> Result<std::collections::HashMap<String, String>> {
    let c = pool.get().await?;
    let rows = db_rows(&c,
        
            "SELECT key, updated_by || ' • ' || to_char(updated_at AT TIME ZONE 'Asia/Jakarta', 'YYYY-MM-DD HH24:MI') AS m FROM site_content",
            &[],
        )
        .await?;
    Ok(rows.iter().map(|r| (r.get("key"), r.get("m"))).collect())
}

// ── Akun admin & sesi ──────────────────────────────────────────────────────

/// Kolom akun admin — SEMUA query memakai alias tabel `u` (admin_users u),
/// jadi satu konstanta berlaku juga untuk JOIN dengan admin_sessions.
const ADMIN_COLS: &str = "u.id, u.username, u.name, u.role, u.active,
    COALESCE(to_char(u.last_login_at AT TIME ZONE 'Asia/Jakarta', 'YYYY-MM-DD HH24:MI'), '') AS last_login";

fn row_to_admin(r: &Row) -> AdminUser {
    AdminUser {
        id: r.get("id"),
        username: r.get("username"),
        name: r.get("name"),
        role: r.get("role"),
        active: r.get("active"),
        last_login: r.get("last_login"),
    }
}

pub async fn admin_count(pool: &Pool) -> Result<i64> {
    let c = pool.get().await?;
    Ok(db_row(&c,"SELECT COUNT(*) FROM admin_users", &[]).await?.get(0))
}

pub async fn admins(pool: &Pool) -> Result<Vec<AdminUser>> {
    let c = pool.get().await?;
    let sql = format!("SELECT {ADMIN_COLS} FROM admin_users u ORDER BY u.active DESC, u.role, u.username");
    Ok(db_rows(&c,&sql, &[]).await?.iter().map(row_to_admin).collect())
}

/// (user, hash sandi) untuk login.
pub async fn admin_login_row(pool: &Pool, username: &str) -> Result<Option<(AdminUser, String)>> {
    let c = pool.get().await?;
    let sql = format!("SELECT {ADMIN_COLS}, u.password_hash FROM admin_users u WHERE u.username = $1");
    Ok(db_opt(&c,&sql, &[&username]).await?.map(|r| (row_to_admin(&r), r.get("password_hash"))))
}

pub async fn create_admin(pool: &Pool, username: &str, name: &str, hash: &str, role: &str) -> Result<i64> {
    let c = pool.get().await?;
    Ok(db_row(&c,
        
            "INSERT INTO admin_users (username, name, password_hash, role) VALUES ($1, $2, $3, $4) RETURNING id",
            &[&username, &name, &hash, &role],
        )
        .await
        .context("insert admin")?
        .get(0))
}

pub async fn update_admin(pool: &Pool, id: i64, name: &str, role: &str, active: bool) -> Result<()> {
    let c = pool.get().await?;
    db_exec(&c,"UPDATE admin_users SET name = $2, role = $3, active = $4 WHERE id = $1", &[&id, &name, &role, &active]).await?;
    if !active {
        db_exec(&c,"DELETE FROM admin_sessions WHERE user_id = $1", &[&id]).await?;
    }
    Ok(())
}

/// Ganti sandi & keluarkan semua sesi akun itu kecuali `keep` (hash token).
pub async fn set_admin_password(pool: &Pool, id: i64, hash: &str, keep: Option<&str>) -> Result<()> {
    // Ganti sandi & keluarkan sesi lain secara atomik (satu pernyataan).
    let c = pool.get().await?;
    db_exec(
        &c,
        "WITH u AS (UPDATE admin_users SET password_hash = $2 WHERE id = $1 RETURNING id)
         DELETE FROM admin_sessions s USING u WHERE s.user_id = u.id AND s.token_hash <> COALESCE($3, '')",
        &[&id, &hash, &keep],
    )
    .await?;
    Ok(())
}

/// Jumlah akun admin aktif selain `except` — cegah panel tanpa admin.
pub async fn other_active_admins(pool: &Pool, except: i64) -> Result<i64> {
    let c = pool.get().await?;
    Ok(db_row(&c,
        "SELECT COUNT(*) FROM admin_users WHERE role = 'admin' AND active AND id <> $1", &[&except])
        .await?
        .get(0))
}

pub async fn create_session(pool: &Pool, token_hash: &str, user_id: i64, days: i64) -> Result<()> {
    let c = pool.get().await?;
    db_exec(&c,
        "INSERT INTO admin_sessions (token_hash, user_id, expires_at) VALUES ($1, $2, NOW() + make_interval(days => $3::int))",
        &[&token_hash, &user_id, &(days as i32)],
    )
    .await?;
    db_exec(&c,"UPDATE admin_users SET last_login_at = NOW() WHERE id = $1", &[&user_id]).await?;
    Ok(())
}

/// Hapus sesi kedaluwarsa — dijalankan tugas latar (server/cleanup.rs),
/// jadi tabel tetap bersih walau lama tak ada yang login.
/// Kunci story (migrasi 026) yang sudah terpakai / kedaluwarsa > 1 hari —
/// tanpa ini tabel tumbuh terus (satu baris per permintaan kunci). Tabel
/// belum ada → 0.
pub async fn purge_story_keys(pool: &Pool) -> Result<u64> {
    let c = pool.get().await?;
    if db_opt(&c, "SELECT to_regclass('story_keys')::TEXT", &[]).await?.and_then(|r| r.get::<_, Option<String>>(0)).is_none() {
        return Ok(0);
    }
    Ok(db_exec(&c, "DELETE FROM story_keys WHERE expires_at < NOW() - INTERVAL '1 day'", &[]).await?)
}

pub async fn purge_expired_sessions(pool: &Pool) -> Result<u64> {
    let c = pool.get().await?;
    Ok(db_exec(&c, "DELETE FROM admin_sessions WHERE expires_at < NOW()", &[]).await?)
}

pub async fn session_user(pool: &Pool, token_hash: &str) -> Result<Option<AdminUser>> {
    let c = pool.get().await?;
    let sql = format!(
        "SELECT {ADMIN_COLS} FROM admin_sessions s JOIN admin_users u ON u.id = s.user_id
         WHERE s.token_hash = $1 AND s.expires_at > NOW() AND u.active"
    );
    Ok(db_opt(&c,&sql, &[&token_hash]).await?.as_ref().map(row_to_admin))
}

pub async fn delete_session(pool: &Pool, token_hash: &str) -> Result<()> {
    let c = pool.get().await?;
    db_exec(&c,"DELETE FROM admin_sessions WHERE token_hash = $1", &[&token_hash]).await?;
    Ok(())
}

// ── Pembersihan pesanan belum dibayar ──────────────────────────────────────

/// Undangan yang dihapus + URL file unggahannya (untuk dibersihkan di RustFS).
pub struct Purged {
    pub slug: String,
    pub files: Vec<String>,
}

/// Hapus ATOMIK undangan yang masih `menunggu_pembayaran` lebih dari `hours`
/// jam (tamu, RSVP, tanda kasih ikut terhapus lewat ON DELETE CASCADE).
/// Admin yang mengaktifkan di detik yang sama menang: syarat status dicek di
/// pernyataan DELETE itu sendiri.
pub async fn purge_unpaid(pool: &Pool, hours: i64) -> Result<Vec<Purged>> {
    let c = pool.get().await?;
    let rows = db_rows(&c,
        
            "DELETE FROM invitations
             WHERE status = 'menunggu_pembayaran' AND NOT is_demo
               -- Sudah kirim bukti transfer → jangan dihapus (lewat jsonb: aman sebelum 017).
               AND to_jsonb(invitations) ->> 'payment_proof_at' IS NULL
               AND created_at < NOW() - make_interval(hours => $1::int)
             RETURNING to_jsonb(invitations) AS j",
            &[&(hours as i32)],
        )
        .await
        .context("purge unpaid")?;
    Ok(rows
        .iter()
        .map(|r| {
            let j: Value = r.get("j");
            let s = |k: &str| j.get(k).and_then(|v| v.as_str()).unwrap_or("").to_string();
            let mut files: Vec<String> =
                ["bride_photo", "groom_photo", "music_url", "cover_photo", "payment_proof"].iter().map(|c| s(c)).filter(|u| !u.is_empty()).collect();
            files.extend(j.get("gallery").cloned().map(json::<Vec<String>>).unwrap_or_default());
            Purged { slug: s("slug"), files }
        })
        .collect())
}

/// Menit tersisa sebelum pesanan belum-dibayar dihapus (None = sudah aktif/demo).
pub async fn unpaid_minutes_left(pool: &Pool, inv_id: i64, hours: i64) -> Result<Option<i64>> {
    let c = pool.get().await?;
    let r = db_opt(&c,
        
            "SELECT GREATEST(0, EXTRACT(EPOCH FROM (created_at + make_interval(hours => $2::int) - NOW())) / 60)::BIGINT
             FROM invitations WHERE id = $1 AND status = 'menunggu_pembayaran' AND NOT is_demo
               AND to_jsonb(invitations) ->> 'payment_proof_at' IS NULL",
            &[&inv_id, &(hours as i32)],
        )
        .await?;
    Ok(r.map(|r| r.get(0)))
}

// ── Animasi kustom (animations) ────────────────────────────────────────────

pub async fn animations(pool: &Pool) -> Result<Vec<crate::web::anim::AnimInfo>> {
    let c = pool.get().await?;
    let rows = db_rows(&c,"SELECT to_jsonb(a) AS j FROM animations a", &[]).await.context("select animations")?;
    Ok(rows
        .iter()
        .filter_map(|r| {
            let j = r.get::<_, Value>("j");
            // Tabel versi 007 (belum migrasi 008): kunci tema = "k-" + slug.
            let legacy = j.get("builtin").is_none();
            let mut a: crate::web::anim::AnimInfo = serde_json::from_value(j).ok()?;
            if legacy && !a.slug.starts_with("k-") {
                a.slug = format!("k-{}", a.slug);
            }
            Some(a)
        })
        .collect())
}

/// Simpan animasi. `edited` = disunting admin (animasi bawaan berhenti ikut
/// pembaruan kode); "Kembalikan ke bawaan" menyimpan dengan `edited = false`.
pub async fn upsert_animation(pool: &Pool, a: &crate::web::anim::AnimInfo, edited: bool) -> Result<()> {
    let c = pool.get().await?;
    let spec = serde_json::to_value(&a.spec)?;
    db_exec(&c,
        "INSERT INTO animations (kind, slug, name, spec, css, builtin, sort_order, edited) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
         ON CONFLICT (kind, slug) DO UPDATE SET name = EXCLUDED.name, spec = EXCLUDED.spec, css = EXCLUDED.css,
             builtin = EXCLUDED.builtin, sort_order = EXCLUDED.sort_order, edited = EXCLUDED.edited, updated_at = NOW()",
        &[&a.kind, &a.slug, &a.name, &spec, &a.css, &a.builtin, &a.sort_order, &edited],
    )
    .await
    .context("upsert animation")?;
    Ok(())
}

/// Isi animasi bawaan dari kode: baris baru ditambah, baris bawaan yang
/// BELUM disunting admin diperbarui bila isinya berubah (migrasi 041) —
/// perbaikan gerak di repo langsung sampai ke tamu tanpa "Kembalikan ke
/// bawaan". Suntingan admin (`edited`) tak pernah ditimpa. Dipanggil saat
/// start; tabel belum migrasi 008/041 → error diabaikan pemanggil.
pub async fn seed_animations(pool: &Pool, list: &[crate::web::anim::AnimInfo]) -> Result<u64> {
    // Satu pernyataan untuk semua animasi bawaan (bukan satu INSERT per baris).
    let rows: Vec<Value> = list
        .iter()
        .map(|a| serde_json::json!({ "kind": a.kind, "slug": a.slug, "name": a.name, "spec": a.spec, "css": a.css, "sort_order": a.sort_order }))
        .collect();
    let c = pool.get().await?;
    db_exec(
        &c,
        "INSERT INTO animations (kind, slug, name, spec, css, builtin, sort_order)
         SELECT x.kind, x.slug, x.name, x.spec, x.css, TRUE, x.sort_order
           FROM jsonb_to_recordset($1) AS x(kind TEXT, slug TEXT, name TEXT, spec JSONB, css TEXT, sort_order INT)
         ON CONFLICT (kind, slug) DO UPDATE
             SET name = EXCLUDED.name, spec = EXCLUDED.spec, css = EXCLUDED.css, sort_order = EXCLUDED.sort_order, updated_at = NOW()
           WHERE animations.builtin AND NOT animations.edited
             AND (animations.css, animations.spec, animations.name) IS DISTINCT FROM (EXCLUDED.css, EXCLUDED.spec, EXCLUDED.name)",
        &[&Value::Array(rows)],
    )
    .await
    .context("seed animations")
}

/// Tema yang memakai animasi `key` jenis `kind` — animasi dipakai tak boleh dihapus.
pub async fn animation_users(pool: &Pool, kind: &str, key: &str) -> Result<Vec<String>> {
    let col = match kind {
        "buka" => "open_anim",
        "scroll" => "scroll_anim",
        _ => "float_deco",
    };
    let c = pool.get().await?;
    let rows = db_rows(&c,&format!("SELECT name FROM themes WHERE {col} = $1 ORDER BY name"), &[&key]).await?;
    Ok(rows.iter().map(|r| r.get(0)).collect())
}

pub async fn delete_animation(pool: &Pool, kind: &str, slug: &str) -> Result<()> {
    let c = pool.get().await?;
    db_exec(&c,"DELETE FROM animations WHERE kind = $1 AND slug = $2 AND NOT builtin", &[&kind, &slug]).await?;
    Ok(())
}

// ── Ornamen tema (tabel theme_ornaments) ─────────────────────────────────

pub async fn ornaments(pool: &Pool) -> Result<Vec<crate::web::ornamen::Ornament>> {
    let c = pool.get().await?;
    let rows = db_rows(&c,
        "SELECT to_jsonb(o) AS j FROM theme_ornaments o ORDER BY theme, bagian, urutan, id", &[])
        .await
        .context("select theme_ornaments")?;
    Ok(rows.iter().filter_map(|r| serde_json::from_value(r.get::<_, Value>("j")).ok()).collect())
}

/// Peta aset statis di RustFS (migrasi 038): (jalur situs, URL publik).
pub async fn aset(pool: &Pool) -> Result<Vec<(String, String)>> {
    let c = pool.get().await?;
    let rows = db_rows(&c, "SELECT jalur, url FROM aset", &[]).await.context("select aset")?;
    Ok(rows.iter().map(|r| (r.get(0), r.get(1))).collect())
}

/// Simpan ornamen (id 0 = baru). Mengembalikan id.
pub async fn save_ornament(pool: &Pool, o: &crate::web::ornamen::Ornament) -> Result<i64> {
    let c = pool.get().await?;
    let p: [&(dyn tokio_postgres::types::ToSql + Sync); 19] = [
        &o.theme, &o.bagian, &o.img, &o.posisi, &o.x, &o.y, &o.lebar, &o.rotasi, &o.cermin, &o.masuk, &o.jeda,
        &o.durasi, &o.gerak, &o.kecepatan, &o.depan, &o.hp, &o.opasitas, &o.urutan, &o.id,
    ];
    let row = if o.id == 0 {
        db_row(&c,
            "INSERT INTO theme_ornaments (theme, bagian, img, posisi, x, y, lebar, rotasi, cermin, masuk, jeda,
                                          durasi, gerak, kecepatan, depan, hp, opasitas, urutan)
             VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18)
             RETURNING id",
            &p[..18],
        )
        .await
    } else {
        db_row(&c,
            "UPDATE theme_ornaments SET bagian=$2, img=$3, posisi=$4, x=$5, y=$6, lebar=$7, rotasi=$8, cermin=$9,
                    masuk=$10, jeda=$11, durasi=$12, gerak=$13, kecepatan=$14, depan=$15, hp=$16, opasitas=$17,
                    urutan=$18, updated_at=NOW()
              WHERE id = $19 AND theme = $1 RETURNING id",
            &p,
        )
        .await
    }
    .context("simpan ornamen")?;
    let id: i64 = row.get(0);
    // Disunting/dibuat dari admin → bukan lagi seed (017b): seed ulang tak menyentuhnya.
    ignore_missing_column(
        db_exec(&c, "UPDATE theme_ornaments SET source = 'admin' WHERE id = $1 AND source <> 'admin'", &[&id]).await,
        "tandai ornamen admin",
    )?;
    Ok(id)
}

pub async fn delete_ornament(pool: &Pool, theme: &str, id: i64) -> Result<()> {
    let c = pool.get().await?;
    db_exec(&c,"DELETE FROM theme_ornaments WHERE id = $1 AND theme = $2", &[&id, &theme]).await?;
    Ok(())
}

/// Salin semua ornamen tema `from` ke tema `to` (ditambahkan, tak menimpa).
pub async fn copy_ornaments(pool: &Pool, from: &str, to: &str) -> Result<u64> {
    let c = pool.get().await?;
    Ok(db_exec(&c,
        "INSERT INTO theme_ornaments (theme, bagian, img, posisi, x, y, lebar, rotasi, cermin, masuk, jeda,
                                      durasi, gerak, kecepatan, depan, hp, opasitas, urutan)
         SELECT $2, bagian, img, posisi, x, y, lebar, rotasi, cermin, masuk, jeda, durasi, gerak, kecepatan,
                depan, hp, opasitas, urutan
           FROM theme_ornaments WHERE theme = $1 ORDER BY bagian, urutan, id",
        &[&from, &to],
    )
    .await?)
}

// ── Banner beranda (tabel banners) ────────────────────────────────────────

const BANNER_COLS: &str = "id, judul, sub, cta, link, img, img_hp, aktif, urutan,
    COALESCE(to_char(mulai AT TIME ZONE 'Asia/Jakarta', 'YYYY-MM-DD\"T\"HH24:MI'), '') AS mulai,
    COALESCE(to_char(selesai AT TIME ZONE 'Asia/Jakarta', 'YYYY-MM-DD\"T\"HH24:MI'), '') AS selesai,
    CASE WHEN NOT aktif THEN 'nonaktif'
         WHEN mulai IS NOT NULL AND mulai > NOW() THEN 'terjadwal'
         WHEN selesai IS NOT NULL AND selesai <= NOW() THEN 'berakhir'
         ELSE 'tayang' END AS status";

fn banner_row(r: &tokio_postgres::Row) -> crate::web::model::Banner {
    crate::web::model::Banner {
        id: r.get("id"),
        judul: r.get("judul"),
        sub: r.get("sub"),
        cta: r.get("cta"),
        link: r.get("link"),
        img: r.get("img"),
        img_hp: r.get("img_hp"),
        aktif: r.get("aktif"),
        urutan: r.get("urutan"),
        mulai: r.get("mulai"),
        selesai: r.get("selesai"),
        status: r.get("status"),
    }
}

/// Banner yang sedang tayang (aktif & dalam jadwal), urut.
pub async fn banners_live(pool: &Pool) -> Result<Vec<crate::web::model::Banner>> {
    let c = pool.get().await?;
    let rows = db_rows(&c,
        
            &format!(
                "SELECT {BANNER_COLS} FROM banners
                  WHERE aktif AND img <> '' AND (mulai IS NULL OR mulai <= NOW()) AND (selesai IS NULL OR selesai > NOW())
                  ORDER BY urutan, id"
            ),
            &[],
        )
        .await
        .context("select banners")?;
    // `{demo}` di tautan = undangan demo saat ini (rename demo tak perlu ubah data).
    let demo = crate::web::themes::DEMO_SLUG;
    Ok(rows.iter().map(banner_row).map(|mut b| { b.link = b.link.replace("{demo}", demo); b }).collect())
}

pub async fn banners_all(pool: &Pool) -> Result<Vec<crate::web::model::Banner>> {
    let c = pool.get().await?;
    let rows = db_rows(&c,&format!("SELECT {BANNER_COLS} FROM banners ORDER BY urutan, id"), &[]).await.context("select banners")?;
    Ok(rows.iter().map(banner_row).collect())
}

/// Simpan (id 0 = baru, urutan paling akhir). Jadwal = `YYYY-MM-DDTHH:MM` WIB / kosong.
pub async fn save_banner(pool: &Pool, b: &crate::web::model::Banner) -> Result<i64> {
    let c = pool.get().await?;
    let row = if b.id == 0 {
        db_row(&c,
            "INSERT INTO banners (judul, sub, cta, link, img, img_hp, aktif, urutan, mulai, selesai)
             VALUES ($1, $2, $3, $4, $5, $6, $7, (SELECT COALESCE(MAX(urutan), 0) + 10 FROM banners),
                     NULLIF($8, '')::timestamp AT TIME ZONE 'Asia/Jakarta', NULLIF($9, '')::timestamp AT TIME ZONE 'Asia/Jakarta')
             RETURNING id",
            &[&b.judul, &b.sub, &b.cta, &b.link, &b.img, &b.img_hp, &b.aktif, &b.mulai, &b.selesai],
        )
        .await
    } else {
        db_row(&c,
            "UPDATE banners SET judul = $2, sub = $3, cta = $4, link = $5, img = $6, img_hp = $7, aktif = $8, urutan = $9,
                    mulai = NULLIF($10, '')::timestamp AT TIME ZONE 'Asia/Jakarta',
                    selesai = NULLIF($11, '')::timestamp AT TIME ZONE 'Asia/Jakarta', updated_at = NOW()
              WHERE id = $1 RETURNING id",
            &[&b.id, &b.judul, &b.sub, &b.cta, &b.link, &b.img, &b.img_hp, &b.aktif, &b.urutan, &b.mulai, &b.selesai],
        )
        .await
    }
    .context("simpan banner")?;
    Ok(row.get(0))
}

pub async fn delete_banner(pool: &Pool, id: i64) -> Result<()> {
    let c = pool.get().await?;
    db_exec(&c,"DELETE FROM banners WHERE id = $1", &[&id]).await?;
    Ok(())
}

/// Geser satu banner naik/turun lalu rapikan urutan menjadi 10, 20, 30, …
pub async fn move_banner(pool: &Pool, id: i64, up: bool) -> Result<()> {
    move_ordered(pool, Urutan::Banner, id, up).await
}

// ── Story panduan beranda (migrasi 037) ────────────────────────────────────

fn site_story_row(r: &tokio_postgres::Row) -> crate::web::model::SiteStory {
    crate::web::model::SiteStory {
        id: r.get("id"),
        judul: r.get("judul"),
        teks: r.get("teks"),
        img: r.get("img"),
        tautan: r.get("tautan"),
        tombol: r.get("tombol"),
        aktif: r.get("aktif"),
        urutan: r.get("urutan"),
    }
}

/// `aktif_saja` = beranda; admin melihat semuanya.
pub async fn site_stories(pool: &Pool, aktif_saja: bool) -> Result<Vec<crate::web::model::SiteStory>> {
    let c = pool.get().await?;
    let rows = db_rows(&c,
        "SELECT id, judul, teks, img, tautan, tombol, aktif, urutan FROM site_stories
          WHERE aktif OR NOT $1 ORDER BY urutan, id",
        &[&aktif_saja],
    )
    .await
    .context("select site_stories")?;
    Ok(rows.iter().map(site_story_row).collect())
}

/// Simpan (id 0 = baru, paling akhir). Mengembalikan id.
pub async fn save_site_story(pool: &Pool, s: &crate::web::model::SiteStory) -> Result<i64> {
    let c = pool.get().await?;
    let row = if s.id == 0 {
        db_row(&c,
            "INSERT INTO site_stories (judul, teks, img, tautan, tombol, aktif, urutan)
             VALUES ($1, $2, $3, $4, $5, $6, (SELECT COALESCE(MAX(urutan), 0) + 10 FROM site_stories)) RETURNING id",
            &[&s.judul, &s.teks, &s.img, &s.tautan, &s.tombol, &s.aktif],
        )
        .await
    } else {
        db_row(&c,
            "UPDATE site_stories SET judul = $2, teks = $3, img = $4, tautan = $5, tombol = $6, aktif = $7, updated_at = NOW()
              WHERE id = $1 RETURNING id",
            &[&s.id, &s.judul, &s.teks, &s.img, &s.tautan, &s.tombol, &s.aktif],
        )
        .await
    }
    .context("simpan story panduan")?;
    Ok(row.get(0))
}

/// Hapus; mengembalikan URL gambar agar berkas RustFS-nya ikut dihapus.
pub async fn delete_site_story(pool: &Pool, id: i64) -> Result<Option<String>> {
    let c = pool.get().await?;
    Ok(db_opt(&c, "DELETE FROM site_stories WHERE id = $1 RETURNING img", &[&id]).await?.map(|r| r.get(0)))
}

/// Geser naik/turun lalu rapikan urutan 10, 20, 30, …
pub async fn move_site_story(pool: &Pool, id: i64, up: bool) -> Result<()> {
    move_ordered(pool, Urutan::SiteStory, id, up).await
}

// ── Story tamu (migrasi 026) ───────────────────────────────────────────────

/// Story undangan, terbaru dulu. `my_hash` = SHA-256 token cookie pembuat
/// (perangkat ini) → `mine`. Kolom token (028) dibaca lewat jsonb.
pub async fn stories(pool: &Pool, inv_id: i64, my_hash: &str) -> Result<Vec<StoryItem>> {
    let c = pool.get().await?;
    let rows = db_rows(&c,
        "SELECT id, name, photo_url, filter, caption, EXTRACT(EPOCH FROM NOW() - created_at)::BIGINT AS age,
                ($2 <> '' AND COALESCE(to_jsonb(s) ->> 'owner_token_hash', '') = $2) AS mine
           FROM invitation_stories s WHERE invitation_id = $1 ORDER BY created_at DESC LIMIT 200",
        &[&inv_id, &my_hash]).await.context("muat story (sudah menjalankan migration/026_story.sql?)")?;
    Ok(rows
        .iter()
        .map(|r| StoryItem {
            id: r.get("id"),
            name: r.get("name"),
            photo: r.get("photo_url"),
            filter: r.get("filter"),
            caption: r.get("caption"),
            ago: lalu(r.get("age")),
            mine: r.get("mine"),
        })
        .collect())
}

fn story_mod_row(r: &Row) -> StoryMod {
    StoryMod {
        id: r.get("id"),
        name: r.get("name"),
        photo: r.get("photo_url"),
        filter: r.get("filter"),
        caption: r.get("caption"),
        ago: lalu(r.get("age")),
        phone: mask_phone(r.get::<_, &str>("phone")),
        slug: r.get("slug"),
        couple: format!("{} & {}", r.get::<_, String>("bride_name"), r.get::<_, String>("groom_name")),
    }
}

/// Satu halaman moderasi. `inv_id` = undangan tertentu (Kelola) atau semua
/// (admin, `q` = cari slug / nama pengirim). `page` mulai 1.
pub async fn stories_page(pool: &Pool, inv_id: Option<i64>, q: &str, page: i64) -> Result<StoryModPage> {
    let c = pool.get().await?;
    let q = q.replace(['%', '_'], "");
    let like = format!("%{q}%");
    let inv = inv_id.unwrap_or(0);
    // Tipe parameter WAJIB eksplisit: tanpa cast Postgres menebak `$1 = 0`
    // sebagai int4 → i64 dari Rust ditolak ("cannot convert … int4").
    let filter = "($1::BIGINT = 0 OR s.invitation_id = $1::BIGINT) AND ($2::TEXT = '' OR i.slug ILIKE $3::TEXT OR s.name ILIKE $3::TEXT)";
    let total: i64 = db_row(&c,
        &format!("SELECT COUNT(*) FROM invitation_stories s JOIN invitations i ON i.id = s.invitation_id WHERE {filter}"),
        &[&inv, &q, &like]).await.context("hitung story")?.get(0);
    let pages = ((total + STORY_PER_PAGE - 1) / STORY_PER_PAGE).max(1);
    let page = page.clamp(1, pages);
    let rows = db_rows(&c,
        &format!("SELECT s.id, s.name, s.photo_url, s.filter, s.caption, s.phone, i.slug, i.bride_name, i.groom_name,
                         EXTRACT(EPOCH FROM NOW() - s.created_at)::BIGINT AS age
                    FROM invitation_stories s JOIN invitations i ON i.id = s.invitation_id
                   WHERE {filter} ORDER BY s.created_at DESC, s.id DESC LIMIT $4::BIGINT OFFSET $5::BIGINT"),
        &[&inv, &q, &like, &STORY_PER_PAGE, &((page - 1) * STORY_PER_PAGE)]).await.context("halaman story")?;
    Ok(StoryModPage { items: rows.iter().map(story_mod_row).collect(), total, page, pages })
}

/// Nomor ini sudah punya story di undangan ini?
pub async fn story_phone_taken(pool: &Pool, inv_id: i64, phone: &str) -> Result<bool> {
    let c = pool.get().await?;
    Ok(db_opt(&c, "SELECT 1 FROM invitation_stories WHERE invitation_id = $1 AND phone = $2", &[&inv_id, &phone])
        .await?
        .is_some())
}

/// Jumlah kunci yang diminta nomor ini dalam 1 jam terakhir (batas kirim WA).
pub async fn story_keys_recent(pool: &Pool, inv_id: i64, phone: &str) -> Result<i64> {
    let c = pool.get().await?;
    Ok(db_row(&c,
        "SELECT COUNT(*) FROM story_keys WHERE invitation_id = $1 AND phone = $2 AND created_at > NOW() - INTERVAL '1 hour'",
        &[&inv_id, &phone]).await?.get(0))
}

pub async fn insert_story_key(pool: &Pool, inv_id: i64, phone: &str, name: &str, key_hash: &str) -> Result<()> {
    let c = pool.get().await?;
    db_exec(&c,
        "INSERT INTO story_keys (invitation_id, phone, name, key_hash) VALUES ($1, $2, $3, $4)",
        &[&inv_id, &phone, &name, &key_hash]).await?;
    Ok(())
}

/// Cocokkan kunci terbaru yang belum dipakai & belum kedaluwarsa. Cocok →
/// `Some(nama)` (belum ditandai terpakai — baru setelah story tersimpan, agar
/// unggahan yang gagal tak menghanguskan kunci). Salah → percobaan +1; kunci
/// mati setelah 5 kali salah.
///
/// SATU pernyataan atomik: baris dikunci (FOR UPDATE) lalu `attempts`
/// dinaikkan bila salah. Dulu SELECT lalu UPDATE terpisah → beberapa tebakan
/// paralel sama-sama membaca attempts = 4 dan semuanya lolos dicoba. Kini
/// permintaan yang menunggu kunci baris menilai ulang `attempts < 5` pada versi
/// terbaru (READ COMMITTED), jadi batas 5 benar-benar berlaku. Yang dibandingkan
/// hash SHA-256, bukan kunci asli — perbandingan di SQL tak membocorkan apa pun.
pub async fn check_story_key(pool: &Pool, inv_id: i64, phone: &str, key_hash: &str) -> Result<Option<(i64, String)>> {
    let c = pool.get().await?;
    let Some(r) = db_opt(&c,
        "WITH k AS (
             SELECT id FROM story_keys
              WHERE invitation_id = $1 AND phone = $2 AND used_at IS NULL AND expires_at > NOW() AND attempts < 5
              ORDER BY created_at DESC LIMIT 1
              FOR UPDATE
         )
         UPDATE story_keys s
            SET attempts = s.attempts + CASE WHEN s.key_hash = $3 THEN 0 ELSE 1 END
           FROM k
          WHERE s.id = k.id AND s.attempts < 5
         RETURNING s.id, s.name, s.key_hash = $3 AS cocok",
        &[&inv_id, &phone, &key_hash]).await? else { return Ok(None) };
    Ok(r.get::<_, bool>("cocok").then(|| (r.get("id"), r.get("name"))))
}

pub async fn use_story_key(pool: &Pool, key_id: i64) -> Result<()> {
    let c = pool.get().await?;
    db_exec(&c, "UPDATE story_keys SET used_at = NOW() WHERE id = $1", &[&key_id]).await?;
    Ok(())
}

/// Isi story baru dari tamu (lihat [`insert_story`]).
pub struct StoryBaru<'a> {
    pub phone: &'a str,
    pub name: &'a str,
    pub photo: &'a str,
    pub filter: &'a str,
    pub caption: &'a str,
    pub token_hash: &'a str,
}

/// Jumlah story di undangan ini (kuota paket `maks_story`).
pub async fn story_count(pool: &Pool, inv_id: i64) -> Result<i64> {
    let c = pool.get().await?;
    Ok(db_opt(&c, "SELECT COUNT(*) FROM invitation_stories WHERE invitation_id = $1", &[&inv_id]).await?.map(|r| r.get(0)).unwrap_or(0))
}

/// Simpan story; `false` bila nomor ini sudah punya story (UNIQUE).
pub async fn insert_story(pool: &Pool, inv_id: i64, s: &StoryBaru<'_>) -> Result<bool> {
    let StoryBaru { phone, name, photo, filter, caption, token_hash } = *s;
    let c = pool.get().await?;
    let n = db_exec(&c,
        "INSERT INTO invitation_stories (invitation_id, phone, name, photo_url, filter, caption, owner_token_hash)
         VALUES ($1, $2, $3, $4, $5, $6, $7) ON CONFLICT (invitation_id, phone) DO NOTHING",
        &[&inv_id, &phone, &name, &photo, &filter, &caption, &token_hash]).await;
    match n {
        Ok(n) => Ok(n == 1),
        // Sebelum migrasi 028 (kolom token belum ada) → simpan tanpa token.
        Err(e) if e.code() == Some(&tokio_postgres::error::SqlState::UNDEFINED_COLUMN) => Ok(db_exec(&c,
            "INSERT INTO invitation_stories (invitation_id, phone, name, photo_url, filter, caption)
             VALUES ($1, $2, $3, $4, $5, $6) ON CONFLICT (invitation_id, phone) DO NOTHING",
            &[&inv_id, &phone, &name, &photo, &filter, &caption]).await? == 1),
        Err(e) => Err(e.into()),
    }
}

/// Hapus permanen oleh PEMBUAT dari perangkatnya (token cookie cocok) → URL foto.
pub async fn delete_story_by_token(pool: &Pool, inv_id: i64, id: i64, token_hash: &str) -> Result<Option<String>> {
    if token_hash.is_empty() {
        return Ok(None);
    }
    let c = pool.get().await?;
    Ok(db_opt(&c,
        "DELETE FROM invitation_stories s WHERE invitation_id = $1 AND id = $2
           AND COALESCE(to_jsonb(s) ->> 'owner_token_hash', '') = $3 RETURNING photo_url",
        &[&inv_id, &id, &token_hash]).await?.map(|r| r.get(0)))
}

/// Hapus permanen oleh PEMBUAT dari perangkat lain (sudah lolos kunci WA).
pub async fn delete_story_by_phone(pool: &Pool, inv_id: i64, phone: &str) -> Result<Option<String>> {
    let c = pool.get().await?;
    Ok(db_opt(&c,
        "DELETE FROM invitation_stories WHERE invitation_id = $1 AND phone = $2 RETURNING photo_url",
        &[&inv_id, &phone]).await?.map(|r| r.get(0)))
}

/// Hapus permanen oleh ADMIN (story undangan mana pun) → URL foto.
pub async fn delete_story_admin(pool: &Pool, id: i64) -> Result<Option<String>> {
    let c = pool.get().await?;
    Ok(db_opt(&c, "DELETE FROM invitation_stories WHERE id = $1 RETURNING photo_url", &[&id]).await?.map(|r| r.get(0)))
}

/// Hapus story (pemilik undangan) → URL foto lama untuk dihapus dari RustFS.
pub async fn delete_story(pool: &Pool, inv_id: i64, id: i64) -> Result<Option<String>> {
    let c = pool.get().await?;
    Ok(db_opt(&c,
        "DELETE FROM invitation_stories WHERE invitation_id = $1 AND id = $2 RETURNING photo_url",
        &[&inv_id, &id]).await?.map(|r| r.get(0)))
}

// ── Pustaka lagu (migrasi 027) ─────────────────────────────────────────────

const SONG_COLS: &str = "id, title, artist, duration, tag, url, aktif, urutan";

fn song_row(r: &Row) -> Song {
    Song {
        id: r.get("id"),
        title: r.get("title"),
        artist: r.get("artist"),
        duration: r.get("duration"),
        tag: r.get("tag"),
        url: r.get("url"),
        aktif: r.get("aktif"),
        urutan: r.get("urutan"),
    }
}

/// `only_active` = pilihan pengantin di /buat; semua = halaman admin.
pub async fn songs(pool: &Pool, only_active: bool) -> Result<Vec<Song>> {
    let c = pool.get().await?;
    let sql = if only_active {
        "SELECT id, title, artist, duration, tag, url, aktif, urutan FROM songs WHERE aktif ORDER BY urutan, id"
    } else {
        "SELECT id, title, artist, duration, tag, url, aktif, urutan FROM songs ORDER BY urutan, id"
    };
    let rows = db_rows(&c, sql, &[]).await.context("muat lagu (sudah menjalankan migration/027_pustaka_lagu.sql?)")?;
    Ok(rows.iter().map(song_row).collect())
}

/// Lagu AKTIF berdasarkan id (pilihan pemesan diverifikasi ulang di server).
pub async fn active_song(pool: &Pool, id: i64) -> Result<Option<Song>> {
    let c = pool.get().await?;
    let sql = format!("SELECT {SONG_COLS} FROM songs WHERE id = $1 AND aktif");
    Ok(db_opt(&c, &sql, &[&id]).await?.as_ref().map(song_row))
}

/// Simpan (id 0 = baru, urutan di akhir) → id.
pub async fn save_song(pool: &Pool, s: &Song) -> Result<i64> {
    let c = pool.get().await?;
    let r = if s.id == 0 {
        db_row(&c,
            "INSERT INTO songs (title, artist, duration, tag, url, aktif, urutan)
             VALUES ($1, $2, $3, $4, $5, $6, (SELECT COALESCE(MAX(urutan), 0) + 10 FROM songs)) RETURNING id",
            &[&s.title, &s.artist, &s.duration, &s.tag, &s.url, &s.aktif]).await?
    } else {
        db_row(&c,
            "UPDATE songs SET title = $2, artist = $3, duration = $4, tag = $5, url = $6, aktif = $7 WHERE id = $1 RETURNING id",
            &[&s.id, &s.title, &s.artist, &s.duration, &s.tag, &s.url, &s.aktif]).await?
    };
    Ok(r.get(0))
}

/// Hapus dari pustaka → (url lama, masih dipakai undangan?). Berkas hanya
/// boleh dihapus dari RustFS bila tak ada undangan yang memakainya.
pub async fn delete_song(pool: &Pool, id: i64) -> Result<Option<(String, bool)>> {
    let c = pool.get().await?;
    let Some(r) = db_opt(&c, "DELETE FROM songs WHERE id = $1 RETURNING url", &[&id]).await? else { return Ok(None) };
    let url: String = r.get(0);
    let used = db_opt(&c, "SELECT 1 FROM invitations WHERE split_part(music_url, '#', 1) = $1 LIMIT 1", &[&url]).await?.is_some();
    Ok(Some((url, used)))
}

/// Tukar urutan dengan tetangga atas/bawah (lalu rapikan 10, 20, …).
pub async fn move_song(pool: &Pool, id: i64, up: bool) -> Result<()> {
    move_ordered(pool, Urutan::Song, id, up).await
}

/// Tabel yang punya kolom `urutan` & diurutkan admin (naik/turun).
#[derive(Clone, Copy)]
enum Urutan {
    Banner,
    SiteStory,
    Song,
}

impl Urutan {
    /// Nama tabel KONSTAN (bukan input) — aman disisipkan ke SQL.
    fn table(self) -> &'static str {
        match self {
            Urutan::Banner => "banners",
            Urutan::SiteStory => "site_stories",
            Urutan::Song => "songs",
        }
    }
}

/// Tukar baris `id` dengan tetangga atas/bawah lalu rapikan urutan 10, 20,
/// 30, … — semua baris dikunci (FOR UPDATE) dan ditulis dalam SATU pernyataan.
async fn move_ordered(pool: &Pool, t: Urutan, id: i64, up: bool) -> Result<()> {
    let table = t.table();
    let mut c = pool.get().await?;
    let tx = c.transaction().await?;
    let mut ids: Vec<i64> = tx
        .query(&format!("SELECT id FROM {table} ORDER BY urutan, id FOR UPDATE"), &[])
        .await?
        .iter()
        .map(|r| r.get(0))
        .collect();
    if let Some(i) = ids.iter().position(|x| *x == id) {
        let j = if up { i.checked_sub(1) } else { (i + 1 < ids.len()).then_some(i + 1) };
        if let Some(j) = j {
            ids.swap(i, j);
        }
    }
    tx.execute(
        &format!("UPDATE {table} t SET urutan = (v.n * 10)::INT FROM unnest($1::BIGINT[]) WITH ORDINALITY AS v(id, n) WHERE t.id = v.id"),
        &[&ids],
    )
    .await
    .with_context(|| format!("urutkan {table}"))?;
    tx.commit().await?;
    Ok(())
}

// ── Tema templat (migrasi 029) ─────────────────────────────────────────────

/// Semua templat. Tabel belum ada → Err (pemanggil memakai templat bawaan).
pub async fn templates(pool: &Pool) -> Result<Vec<super::templat::Templat>> {
    let c = pool.get().await?;
    let rows = db_rows(&c, "SELECT to_jsonb(t) AS j FROM theme_templates t ORDER BY slug", &[])
        .await
        .context("select theme_templates")?;
    Ok(rows.iter().filter_map(|r| serde_json::from_value(r.get::<_, Value>("j")).ok()).collect())
}

/// Isi templat bawaan (berkas templat/ di repo). Baris bawaan yang BELUM
/// disunting admin ikut diperbarui bila isinya berubah — beda dengan animasi
/// bawaan (DO NOTHING) yang membuat perubahan berkas tak pernah sampai ke DB.
pub async fn seed_templates(pool: &Pool, list: &[super::templat::Templat]) -> Result<u64> {
    let rows: Vec<Value> = list
        .iter()
        .map(|t| serde_json::json!({ "slug": t.slug, "name": t.name, "html": t.html, "css": t.css, "fonts": t.fonts, "assets": t.assets }))
        .collect();
    let c = pool.get().await?;
    db_exec(
        &c,
        "INSERT INTO theme_templates (slug, name, html, css, fonts, assets, builtin)
         SELECT x.slug, x.name, x.html, x.css, x.fonts, x.assets, TRUE
           FROM jsonb_to_recordset($1) AS x(slug TEXT, name TEXT, html TEXT, css TEXT, fonts TEXT, assets JSONB)
         ON CONFLICT (slug) DO UPDATE
            SET name = EXCLUDED.name, html = EXCLUDED.html, css = EXCLUDED.css,
                fonts = EXCLUDED.fonts, assets = EXCLUDED.assets, updated_at = NOW()
          WHERE theme_templates.builtin AND NOT theme_templates.edited
            AND (theme_templates.html, theme_templates.css, theme_templates.fonts, theme_templates.assets)
                IS DISTINCT FROM (EXCLUDED.html, EXCLUDED.css, EXCLUDED.fonts, EXCLUDED.assets)",
        &[&Value::Array(rows)],
    )
    .await
    .context("seed theme_templates")
}

/// Simpan suntingan admin (baris bawaan ditandai `edited`).
pub async fn save_template(pool: &Pool, t: &super::templat::Templat) -> Result<()> {
    let c = pool.get().await?;
    let assets = serde_json::to_value(&t.assets)?;
    db_exec(
        &c,
        "INSERT INTO theme_templates (slug, name, html, css, fonts, assets, edited)
         VALUES ($1, $2, $3, $4, $5, $6, TRUE)
         ON CONFLICT (slug) DO UPDATE
            SET name = EXCLUDED.name, html = EXCLUDED.html, css = EXCLUDED.css, fonts = EXCLUDED.fonts,
                assets = EXCLUDED.assets, edited = TRUE, updated_at = NOW()",
        &[&t.slug, &t.name, &t.html, &t.css, &t.fonts, &assets],
    )
    .await
    .context("save theme_template")?;
    Ok(())
}

/// Templat bawaan kembali mengikuti berkas di repo (diisi ulang saat seed berikutnya).
pub async fn reset_template(pool: &Pool, slug: &str) -> Result<u64> {
    let c = pool.get().await?;
    Ok(db_exec(&c, "UPDATE theme_templates SET edited = FALSE WHERE slug = $1 AND builtin", &[&slug]).await?)
}

/// Pasang templat ke tema + aset & CSS tema (templat kosong = kembali ke
/// tampilan komponen bawaan).
pub async fn set_theme_template(
    pool: &Pool,
    theme: &str,
    template: &str,
    assets: &std::collections::BTreeMap<String, String>,
    css: &str,
) -> Result<u64> {
    let c = pool.get().await?;
    let assets = serde_json::to_value(assets)?;
    Ok(db_exec(
        &c,
        "UPDATE themes SET template = $2, template_assets = $3, template_css = $4 WHERE slug = $1",
        &[&theme, &template, &assets, &css],
    )
    .await?)
}
