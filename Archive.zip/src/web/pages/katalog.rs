//! pages/katalog.rs — beranda: katalog & pencarian tema, simulasi monogram,
//! paket harga. Filter = query string (?q=&kategori=&nuansa=&palet=&maks=&urut=)
//! sehingga jalan tanpa JS (form GET) dan bisa dibagikan sebagai tautan.

use leptos::prelude::*;
use crate::web::skeleton::*;
use leptos_router::hooks::use_query_map;

use crate::web::components::{monogram_svg, Monogram};
use crate::web::fmt::{self, rupiah};
use crate::web::icons::Icon;
use crate::web::api::list_themes;
use crate::web::skin::{ThemeInfo, PALETTES};
use crate::web::konten::Konten;

use super::{SiteFooter, SiteHeader};
use crate::web::seo::{self, JsonLd, Seo};

#[derive(Clone, Default, PartialEq)]
struct Filter {
    q: String,
    kategori: String,
    nuansa: Vec<String>,
    palet: String,
    urut: String,
    /// Jumlah kartu yang ditampilkan (bertambah lewat "Tampilkan lebih banyak").
    tampil: usize,
}

/// Kartu per "halaman" katalog.
const PER_HALAMAN: usize = 24;

impl Filter {
    fn matches(&self, t: &ThemeInfo) -> bool {
        let q = self.q.to_lowercase();
        let hay = format!("{} {} {} {} {} {} {}", t.name, t.description, t.region, t.tags.join(" "), t.palette, t.category, t.nuansa)
            .to_lowercase();
        (q.is_empty() || q.split_whitespace().all(|w| hay.contains(w)))
            && (self.kategori.is_empty() || t.category_key() == self.kategori)
            && (self.nuansa.is_empty() || self.nuansa.iter().any(|n| *n == t.nuansa_key()))
            && (self.palet.is_empty() || t.palette == self.palet)
    }

    /// Query string dengan satu kunci diganti (kosong = dihapus).
    fn with(&self, key: &str, val: &str) -> String {
        let mut parts = Vec::new();
        let mut push = |k: &str, v: &str| {
            if !v.is_empty() {
                parts.push(format!("{k}={}", fmt::url_encode(v)));
            }
        };
        push("q", if key == "q" { val } else { &self.q });
        push("kategori", if key == "kategori" { val } else { &self.kategori });
        if key != "nuansa" {
            for n in &self.nuansa {
                push("nuansa", n);
            }
        }
        push("palet", if key == "palet" { val } else { &self.palet });
        push("urut", if key == "urut" { val } else { &self.urut });
        // Ganti filter lain → kembali ke halaman pertama.
        if key == "tampil" {
            push("tampil", val);
        }
        if parts.is_empty() {
            "/#katalog".into()
        } else {
            format!("/?{}#katalog", parts.join("&"))
        }
    }
}

#[component]
pub fn KatalogPage() -> impl IntoView {
    let query = use_query_map();
    let filter = Memo::new(move |_| {
        let q = query.read();
        Filter {
            q: q.get("q").unwrap_or_default().chars().take(60).collect(),
            kategori: q.get("kategori").unwrap_or_default(),
            nuansa: q.get_all("nuansa").unwrap_or_default(),
            palet: q.get("palet").unwrap_or_default(),
            urut: q.get("urut").unwrap_or_default(),
            tampil: q.get("tampil").and_then(|n| n.parse().ok()).unwrap_or(PER_HALAMAN).clamp(PER_HALAMAN, 1000),
        }
    });
    let themes = Resource::new(|| (), |_| list_themes());
    let konten = super::use_konten();
    // Banner beranda (tabel banners, /admin/banner).
    let banners = Resource::new(|| (), |_| crate::web::api::get_banners());
    // Story panduan (tabel site_stories, /admin/story-panduan) — tepat di bawah banner.
    let panduan = Resource::new(|| (), |_| crate::web::api::get_site_stories());
    let from = move || konten.get().and_then(|r| r.ok()).map(|k| k.min_price()).unwrap_or(0);
    // Signal::derive, BUKAN Memo: resource tema harus dibaca di dalam
    // <Suspense/> pemanggilnya — Memo membacanya di konteksnya sendiri (di luar
    // Suspense) → peringatan & risiko hydration mismatch. Pembaca yang cuma
    // butuh jumlah/kosong memakai `.with()` (tanpa mengkloning daftar).
    let all = Signal::derive(move || themes.get().and_then(|r| r.ok()).unwrap_or_default());
    // Kartu tambahan yang dimuat di browser (infinite scroll / tombol) — TANPA
    // navigasi, jadi halaman tak melompat ke atas. `?tampil=` tetap jadi
    // cadangan tanpa JavaScript. Ganti filter → kembali ke halaman pertama.
    let extra = RwSignal::new(0usize);
    let shown = Memo::new(move |_| filter.get().tampil + extra.get());
    Effect::new(move |prev: Option<Filter>| {
        let f = filter.get();
        if let Some(p) = prev {
            if (&p.q, &p.kategori, &p.nuansa, &p.palet, &p.urut) != (&f.q, &f.kategori, &f.nuansa, &f.palet, &f.urut) {
                extra.set(0);
            }
        }
        f
    });
    // Penanda "sudah hydrate": muat otomatis hanya bila klik ditangani Leptos
    // (sebelum itu klik = tautan biasa ?tampil=…).
    let ready = RwSignal::new(false);
    Effect::new(move |_| ready.set(true));
    // HP: panel filter dilipat (dulu terbuka penuh sebelum satu tema pun terlihat).
    let fopen = RwSignal::new(false);
    let aktif = move || {
        let f = filter.get();
        f.nuansa.len() + usize::from(!f.palet.is_empty()) + usize::from(!f.urut.is_empty())
    };
    let results = Signal::derive(move || {
        let f = filter.get();
        let mut v: Vec<ThemeInfo> = all.with(|a| a.iter().filter(|t| f.matches(t)).cloned().collect());
        if f.urut == "baru" {
            v.sort_by_key(|t| std::cmp::Reverse(t.created));
        }
        v
    });
    // (kunci, label, jumlah) dari data — kategori/nuansa baru muncul otomatis.
    let groups = move |field: fn(&ThemeInfo) -> &str| {
        Signal::derive(move || {
            let mut out: Vec<(String, String, usize)> = Vec::new();
            for t in all.with(|a| a.iter().map(|t| field(t).trim().to_string()).collect::<Vec<_>>()) {
                let label = t;
                if label.is_empty() {
                    continue;
                }
                let key = fmt::key(&label);
                match out.iter_mut().find(|g| g.0 == key) {
                    Some(g) => g.2 += 1,
                    None => out.push((key, label, 1)),
                }
            }
            out
        })
    };
    let categories = groups(|t| &t.category);
    let nuansa = groups(|t| &t.nuansa);

    view! {
        <Seo
            title=concat!("Undangan Online Pernikahan — Elegan & Mudah | ", crate::brand!())
            description="Buat undangan online pernikahan dalam 5 menit: tema adat Jawa & Nusantara, RSVP, buku tamu QR, amplop digital, musik & galeri. Coba gratis, bayar saat siap."
            path="/"
        />
        <JsonLd data=seo::org_and_site() />
        <div class="site">
            <SiteHeader active="katalog" />

            // Banner promo lebar (Admin → Konten & Harga → Banner Beranda).
            <Suspense fallback=|| ()>
                {move || banners.get().and_then(|r| r.ok()).map(|items| view! { <BannerCarousel items=items /> })}
            </Suspense>
            <Suspense fallback=|| ()>
                {move || panduan.get().and_then(|r| r.ok()).map(|items| view! { <PanduanStories items=items /> })}
            </Suspense>
            // Etalase HP: tema berjajar (coverflow), yang berhenti di dalam HP
            // langsung memutar gerak bukanya (global.js, mesin pratinjau kartu).
            <Suspense fallback=|| ()>
                {move || themes.get().and_then(|r| r.ok()).filter(|v| !v.is_empty()).map(|v| view! { <EtalaseHp themes=v /> })}
            </Suspense>

            <section class="k-hero">
                <span class="chip chip--soft"><Icon name="auto_awesome" />"Curated Atelier Collection 2026"</span>
                <h1>"Undangan Online Pernikahan dengan Tema "<em>"Impian"</em>" Anda"</h1>
                <p>"Undangan digital berkelas dengan tema adat Nusantara, sentuhan foil emas, dan animasi pembuka premium — tampil sempurna di HP, tablet, maupun desktop."</p>
                <form class="searchbar" method="get" action="/#katalog">
                    <Icon name="search" />
                    <input name="q" placeholder="Cari tema: adat jawa, sage green, modern…" prop:value=move || filter.get().q />
                    <button class="btn btn--primary btn--sm" type="submit">"Cari Tema"</button>
                </form>
                <div class="k-features">
                    <span><Icon name="visibility" />"Coba gratis, bayar saat siap disebar"</span>
                    <span><Icon name="bolt" />"Jadi 5 menit"</span>
                    <span><Icon name="library_music" />"Musik latar bebas"</span>
                    <span><Icon name="qr_code_2" />"Amplop & QR check-in"</span>
                    <span><Icon name="smartphone" />"Mobile optimal"</span>
                </div>
            </section>

            <Suspense fallback=|| view! { <div class="chips-row" id="katalog"></div> }>
                <div class="chips-row" id="katalog">
                    <a class="chip-link" class:is-on=move || filter.get().kategori.is_empty() href=move || filter.get().with("kategori", "")>
                        {move || format!("Semua ({})", all.with(Vec::len))}
                    </a>
                    <For each=move || categories.get() key=|g| g.clone() let:g>
                        {
                            let (k, label, n) = g;
                            let k2 = k.clone();
                            view! {
                                <a class="chip-link" class:is-on=move || filter.get().kategori == k href=move || filter.get().with("kategori", &k2)>
                                    {format!("{label} ({n})")}
                                </a>
                            }
                        }
                    </For>
                </div>
            </Suspense>

            <div class="k-layout">
                <aside class="k-filter card" class:is-open=move || fopen.get()>
                    <form method="get" action="/#katalog">
                        <div class="k-filter__head">
                            // HP: kepala = tombol buka/tutup panel; desktop: judul biasa.
                            <button type="button" class="k-filter__toggle" aria-expanded=move || fopen.get().to_string()
                                on:click=move |_| fopen.update(|o| *o = !*o)>
                                <Icon name="tune" />"Filter Presisi"
                                {move || (aktif() > 0).then(|| view! { <span class="k-filter__badge">{aktif()}</span> })}
                                <Icon name="expand_more" class="k-filter__caret" />
                            </button>
                            <a href="/#katalog">"Reset"</a>
                        </div>
                        <div class="k-filter__body">
                        <input type="hidden" name="q" prop:value=move || filter.get().q />
                        <input type="hidden" name="kategori" prop:value=move || filter.get().kategori />
                        <p class="eyebrow">"Nuansa & Budaya"</p>
                        // Daftar daerah bisa panjang (20+) → kotak bergulir sendiri.
                        <div class="k-filter__list">
                        <Suspense fallback=|| ()>
                            <For each=move || nuansa.get() key=|g| g.clone() let:g>
                                {
                                    let (k, label, n) = g;
                                    let k2 = k.clone();
                                    view! {
                                        <label class="check">
                                            <input type="checkbox" name="nuansa" value=k
                                                prop:checked=move || filter.get().nuansa.contains(&k2) />
                                            <span>{label}</span>
                                            <small>{n}</small>
                                        </label>
                                    }
                                }
                            </For>
                        </Suspense>
                        </div>
                        <p class="eyebrow">"Palet Warna Utama"</p>
                        <div class="palette">
                            {PALETTES.iter().map(|(k, label, hex)| view! {
                                <label class="palette__opt" title=*label>
                                    <input type="radio" name="palet" value=*k prop:checked=move || filter.get().palet == *k />
                                    <i style=format!("background:{hex}")></i>
                                    <small>{*label}</small>
                                </label>
                            }).collect_view()}
                        </div>
                        <p class="eyebrow">"Urutkan Koleksi"</p>
                        <select class="input" name="urut">
                            <option value="" selected=move || filter.get().urut.is_empty()>"Pilihan editor"</option>
                            <option value="baru" selected=move || filter.get().urut == "baru">"Terbaru"</option>
                        </select>
                        <Suspense fallback=|| ()>
                            <p class="k-filter__note"><Icon name="check_circle" />{move || format!("Semua tema termasuk di setiap paket — mulai {}", rupiah(from()))}</p>
                        </Suspense>
                        // Tombol menempel di bawah panel — selalu terjangkau tanpa scroll ke ujung.
                        <div class="k-filter__foot">
                            <button class="btn btn--primary btn--block btn--sm" type="submit"><Icon name="tune" />"Terapkan Filter"</button>
                        </div>
                        </div>
                    </form>
                </aside>

                <div class="k-results">
                    <Suspense fallback=|| view! { <SkelCards n=6 class="theme-grid" /> }>
                        <p class="k-count">
                            <i class="dot"></i>
                            {move || {
                                let f = filter.get();
                                let n = results.with(Vec::len);
                                let shown = n.min(shown.get());
                                let of = if shown < n { format!("{shown} dari {n}") } else { n.to_string() };
                                if f.q.is_empty() { format!("Menampilkan {of} tema adiluhung") }
                                else { format!("Menampilkan {of} tema untuk kata kunci “{}”", f.q) }
                            }}
                        </p>
                        <div class="theme-grid">
                            <For
                                each=move || { let n = shown.get(); results.with(|r| r.iter().take(n).cloned().enumerate().collect::<Vec<_>>()) }
                                key=|(_, t)| t.slug.clone()
                                children=move |(i, t)| {
                                    // Jangkar kartu pertama tiap "halaman" → tombol lebih banyak tak melompat ke atas.
                                    let anchor = (i > 0 && i % PER_HALAMAN == 0).then(|| format!("k-{i}"));
                                    view! { <ThemeCard t=t from=from() anchor=anchor /> }
                                }
                            />
                        </div>
                        {move || {
                            let f = filter.get();
                            let n = shown.get();
                            let total = results.with(Vec::len);
                            let sisa = total.saturating_sub(n);
                            (sisa > 0).then(|| view! {
                                // Paginasi "muat lagi" MANUAL + bilah progres (dulu otomatis
                                // tanpa ujung → info, CTA & footer tak pernah terjangkau).
                                // data-load-more hanya dipakai pemulihan posisi saat Back.
                                <div class="k-more">
                                    <p class="k-more__count">{format!("{n} dari {total} tema")}</p>
                                    <span class="k-more__bar" aria-hidden="true">
                                        <i style=format!("width:{}%", n * 100 / total.max(1))></i>
                                    </span>
                                    <a class="btn btn--outline"
                                        href=f.with("tampil", &(n + PER_HALAMAN).to_string()).replace("#katalog", &format!("#k-{n}"))
                                        data-load-more=move || ready.get().then_some("1")
                                        on:click=move |e| { e.prevent_default(); extra.update(|x| *x += PER_HALAMAN); }>
                                        <Icon name="expand_more" />{format!("Tampilkan {} tema lagi", sisa.min(PER_HALAMAN))}
                                    </a>
                                </div>
                            })
                        }}
                        <Show when=move || results.with(Vec::is_empty)>
                            <div class="empty card">
                                <p>"Belum ada tema yang cocok dengan filter ini."</p>
                                <a class="btn btn--soft btn--sm" href="/#katalog">"Hapus Semua Filter"</a>
                            </div>
                        </Show>
                    </Suspense>
                </div>
            </div>

            <LivePreview />
            <super::layanan::WithKonten view=packages />

            <section class="guarantees">
                <div><Icon name="verified" /><b>"Garansi Uang Kembali 100%"</b><p>"Jika undangan digital Anda tidak memuaskan karena kendala teknis dalam 7 hari aktivasi."</p></div>
                <div><Icon name="support_agent" /><b>"Dukungan WhatsApp 24/7"</b><p>"Tim admin siap membantu input data, import kontak tamu, hingga gladi bersih sebar link."</p></div>
                <div><Icon name="favorite" /><b>"Masa Aktif Selamanya"</b><p>"Kisah cinta dan ucapan doa restu tamu tersimpan abadi tanpa biaya perpanjangan tahunan."</p></div>
            </section>

            <UndanganOnlineInfo />
            <Suspense fallback=|| ()>
                {move || themes.get().and_then(|r| r.ok()).filter(|v| !v.is_empty()).map(|v| view! { <DirektoriTema themes=v /> })}
            </Suspense>

            <SiteFooter />
        </div>
    }
}

#[component]
pub fn ThemeCard(t: ThemeInfo, from: i64, #[prop(default = None)] anchor: Option<String>) -> impl IntoView {
    let rating = (!t.rating.is_empty()).then(|| {
        let r = if t.reviews.is_empty() { t.rating.clone() } else { format!("{} ({})", t.rating, t.reviews) };
        view! { <span class="tcard__rating"><Icon name="star" />{r}</span> }
    });
    // Klik kartu / "Demo" → undangan demo LAYAR PENUH bertema ini (bukan
    // halaman /tema/{slug} dengan bingkai HP). Nama tema tetap menaut ke
    // /tema/{slug} — halaman itu yang diindeks Google (/u/ ber-noindex).
    let demo = format!("/u/{}?tema={}", crate::web::themes::DEMO_SLUG, t.slug);
    view! {
        <article class="tcard card" id=anchor>
            // Kelas rupa: bentuk kartu mini mengikuti sampul tema (web/rupa.rs) —
            // dulu semua kartu katalog sama persis.
            <a class=format!("tcard__art th-{}{}", t.slug, crate::web::rupa::classes(&t.rupa)) href=demo.clone() aria-label=format!("Demo {}", t.name)>
                {(!t.badge.is_empty()).then(|| view! { <span class="tcard__badge"><Icon name="star" />{t.badge.clone()}</span> })}
                <div class="mini">
                    <p class="mini__eyebrow">"The Wedding Of"</p>
                    <Monogram initials="A&R" class="monogram--sm" />
                    <p class="mini__names">"Yona & Doni"</p>
                    <p class="mini__date">"Sabtu, 24 Oktober 2026"</p>
                    <span class="mini__btn">"Buka Undangan"</span>
                </div>
                <span class="tcard__region">{t.region.clone()}</span>
                {rating}
                // Wadah pratinjau bergulir (iframe disisipkan global.js saat hover/sentuh).
                <div class="tcard__pv" data-pv=format!("/u/{}?tema={}&pv=1", crate::web::themes::DEMO_SLUG, t.slug) aria-hidden="true"></div>
            </a>
            <div class="tcard__body">
                <h3><a href=format!("/tema/{}", t.slug)>{t.name.clone()}</a></h3>
                <p class="tcard__desc">{t.description.clone()}</p>
                <div class="tcard__tags">
                    {t.tags.iter().map(|tag| view! { <span class="tag">{tag.clone()}</span> }).collect_view()}
                </div>
                <div class="tcard__foot">
                    <div class="price">
                        <small>"Termasuk semua paket"</small>
                        <b>{format!("mulai {}", rupiah(from))}</b>
                    </div>
                    <div class="tcard__btns">
                        <a class="btn btn--soft btn--sm" href=demo>"Demo"</a>
                        <a class="btn btn--primary btn--sm" href=format!("/buat?tema={}", t.slug)>"Pilih"</a>
                    </div>
                </div>
            </div>
        </article>
    }
}

#[component]
fn LivePreview() -> impl IntoView {
    let pria = RwSignal::new("Doni".to_string());
    let wanita = RwSignal::new("Yona".to_string());
    let tanggal = RwSignal::new("2026-10-24".to_string());
    let initials = move || {
        format!("{}&{}", crate::web::model::initial(&wanita.get()), crate::web::model::initial(&pria.get()))
    };
    let href = move || {
        format!(
            "/buat?wanita={}&pria={}&tanggal={}",
            fmt::url_encode(&wanita.get()),
            fmt::url_encode(&pria.get()),
            fmt::url_encode(&tanggal.get())
        )
    };
    view! {
        <section class="live card">
            <div class="live__form">
                <span class="chip chip--gold"><Icon name="auto_awesome" />{concat!("Fitur Eksklusif ", crate::brand!())}</span>
                <h2>"Coba Live Preview Monogram & Nama Anda"</h2>
                <p class="muted">"Ketik nama Anda dan pasangan untuk langsung melihat simulasi tampilan sampul undangan dengan monogram inisial otomatis."</p>
                <div class="field-row">
                    <label class="field">
                        <span class="field__label">"Mempelai Wanita"</span>
                        <input class="input" maxlength="30" prop:value=move || wanita.get() on:input=move |e| wanita.set(event_target_value(&e)) />
                    </label>
                    <label class="field">
                        <span class="field__label">"Mempelai Pria"</span>
                        <input class="input" maxlength="30" prop:value=move || pria.get() on:input=move |e| pria.set(event_target_value(&e)) />
                    </label>
                </div>
                <label class="field">
                    <span class="field__label">"Tanggal Pernikahan Rencana"</span>
                    <input class="input" type="date" prop:value=move || tanggal.get() on:input=move |e| tanggal.set(event_target_value(&e)) />
                </label>
                <a class="btn btn--primary" href=href>
                    <Icon name="arrow_forward" />
                    "Buat Undangan dengan Nama Ini"
                </a>
            </div>
            <div class="live__card th-botanical-heritage">
                <p class="mini__eyebrow">"The Wedding Of"</p>
                <div class="monogram monogram--md" inner_html=move || monogram_svg(&initials(), "THE WEDDING OF")></div>
                <p class="live__initials">{move || initials().replace('&', " & ")}</p>
                <h3>{move || format!("{} & {}", wanita.get(), pria.get())}</h3>
                <p class="mini__date">{move || fmt::tanggal_panjang(&tanggal.get()).to_uppercase()}</p>
                <div class="live__guest">
                    <small>"Kepada Yth. Bapak/Ibu/Saudara/i:"</small>
                    <b>"Tamu Kehormatan"</b>
                </div>
                <span class="btn btn--primary btn--sm"><Icon name="mail" />"Buka Undangan"</span>
            </div>
        </section>
    }
}

fn packages(k: Konten) -> impl IntoView {
    let kupon = k.active_coupon().map(|c| format!(" • kupon {} potong {}", c.code, rupiah(c.amount))).unwrap_or_default();
    view! {
        <section class="packages" id="paket">
            <p class="eyebrow eyebrow--center">"Transparan & Fleksibel"</p>
            <h2 class="section__title">"Pilihan Paket Undangan"</h2>
            <p class="muted center">"Satu kali bayar, aktif sesuai paket. Tanpa biaya tersembunyi."</p>
            <div class="pkg-grid">
                {k.paket.clone().into_iter().map(|p| view! {
                    <article class="pkg card" class:pkg--popular=p.popular>
                        {p.popular.then(|| view! { <span class="chip chip--gold pkg__flag">"Paling Populer"</span> })}
                        <h3>{p.name.clone()}</h3>
                        <p class="pkg__price">{rupiah(p.price)}</p>
                        <p class="pkg__period">{p.period.clone()}</p>
                        <ul>
                            {p.features.iter().map(|f| view! { <li><Icon name="check_circle" />{f.clone()}</li> }).collect_view()}
                        </ul>
                        <a class=if p.popular { "btn btn--primary btn--block" } else { "btn btn--soft btn--block" }
                            href=format!("/buat?paket={}", p.slug)>
                            {format!("Pilih {}", p.name)}
                        </a>
                    </article>
                }).collect_view()}
            </div>
            <a class="btn btn--outline btn--sm packages__more" href="/paket#fitur">"Bandingkan fitur lengkap tiap paket"<Icon name="arrow_forward" /></a>
            <p class="muted center small">{format!("Semua tema bisa dipakai di paket mana pun • coba & pratinjau gratis, bayar saat siap disebar{kupon}")}</p>
        </section>
    }
}

/// Story PANDUAN beranda (di bawah banner): lingkaran per langkah (pilih tema →
/// pembayaran → konfirmasi admin); ketuk = penampil story layar penuh
/// (global.js, sama dengan story tamu) yang berlanjut ke langkah berikutnya,
/// progress bersegmen + tombol aksi per langkah. Data JSON ditanam di
/// halaman — tanpa request tambahan saat dibuka.
/// Etalase beranda: satu HP di tengah, tema berjajar kiri-kanan (coverflow).
/// Tema yang berhenti tepat di dalam HP diputar seperti kartu yang di-hover
/// (iframe ?pv=1 → gerak buka tema, lalu bergulir). Info & tombol diisi
/// global.js (wadah kosong → tak mengganggu hydrate); tanpa JS, tiap tema
/// tetap tautan ke demonya.
#[component]
fn EtalaseHp(themes: Vec<ThemeInfo>) -> impl IntoView {
    view! {
        <section class="etalase" aria-label="Coba tema undangan di layar HP">
            <div class="etalase__head">
                <span class="chip chip--soft"><Icon name="smartphone" />"Coba langsung"</span>
                <h2>"Geser tema, lihat "<em>"gerak bukanya"</em>" di HP"</h2>
                <p>"Tema yang berhenti di dalam HP langsung diputar seperti undangan sungguhan — sampul terbuka, isi bergulir."</p>
            </div>
            <div class="etalase__stage">
                <div class="etalase__track" data-etalase>
                    // SEMUA tema (dulu dibatasi 24). Kartu jauh dari tengah disembunyikan
                    // global.js (visibility:hidden → tak dilukis, tanpa lapis GPU).
                    // `is-dekat` dari server untuk kartu awal: coverflow sudah benar di
                    // frame pertama (selanjutnya global.js yang memasang/mencabut).
                    {themes.into_iter().enumerate().map(|(i, t)| {
                        let demo = format!("/u/{}?tema={}", crate::web::themes::DEMO_SLUG, t.slug);
                        let dekat = if i < 6 { " is-dekat" } else { "" };
                        view! {
                            <a class=format!("etalase__item tcard__art th-{}{}{dekat}", t.slug, crate::web::rupa::classes(&t.rupa)) href=demo.clone()
                                data-pv=format!("{demo}&pv=1") data-slug=t.slug.clone() data-name=t.name.clone() data-region=t.region.clone()
                                aria-label=format!("Demo {}", t.name)>
                                <div class="mini">
                                    <p class="mini__eyebrow">"The Wedding Of"</p>
                                    <Monogram initials="A&R" class="monogram--sm" />
                                    <p class="mini__names">"Yona & Doni"</p>
                                    <p class="mini__date">"Sabtu, 24 Oktober 2026"</p>
                                    <span class="mini__btn">"Buka Undangan"</span>
                                </div>
                                <span class="etalase__nama">{t.name.clone()}</span>
                            </a>
                        }
                    }).collect_view()}
                </div>
                <div class="etalase__hp" aria-hidden="true">
                    <div class="etalase__layar"><div class="etalase__pv"></div></div>
                </div>
                <div class="etalase__tepi etalase__tepi--l" aria-hidden="true"></div>
                <div class="etalase__tepi etalase__tepi--r" aria-hidden="true"></div>
                <button type="button" class="etalase__nav etalase__nav--prev" data-etalase-nav="-1" aria-label="Tema sebelumnya"><Icon name="chevron_left" /></button>
                <button type="button" class="etalase__nav etalase__nav--next" data-etalase-nav="1" aria-label="Tema berikutnya"><Icon name="chevron_right" /></button>
            </div>
            // Posisi "05 / 24" + garis progres putar otomatis (diisi & diputar global.js).
            <div class="etalase__posisi" aria-hidden="true">
                <span class="etalase__hitung" data-etalase-hitung></span>
                <span class="etalase__progres"><i data-etalase-progres></i></span>
            </div>
            <div class="etalase__info" data-etalase-info aria-live="polite"></div>
            // Laptop: tema yang sama dalam tata letak DESKTOP (iframe 1280 px
            // diskalakan, mesin pratinjau kedua — dimuat setelah HP & hanya
            // bila terlihat). Bergerak seperti HP (prolog 3D + gulir); dibongkar
            // saat tema digeser & saat laptop keluar layar. (`data-pv-beku`
            // = mode beku lama, kini tak dipakai.)
            // Layar kosong = kilau skeleton sampai siap.
            <div class="etalase__laptop" aria-hidden="true">
                <div class="etalase__tutup">
                    <div class="etalase__lyr"><div class="etalase__lpv" data-pv-lebar="1280"></div></div>
                </div>
                <div class="etalase__alas"></div>
                <p class="etalase__ket">"Tampilan di laptop & desktop"</p>
            </div>
        </section>
    }
}

#[component]
fn PanduanStories(items: Vec<crate::web::model::SiteStory>) -> impl IntoView {
    use crate::web::skin::is_safe_url;
    #[derive(serde::Serialize)]
    struct Item {
        id: i64,
        photo: String,
        name: String,
        ago: String,
        caption: String,
        filter: &'static str,
        link: String,
        cta: String,
    }
    let items: Vec<_> = items.into_iter().filter(|s| is_safe_url(&s.img)).collect();
    let n = items.len();
    (n > 0).then(|| {
        let data: Vec<Item> = items
            .iter()
            .enumerate()
            .map(|(i, s)| Item {
                id: s.id,
                photo: s.img.clone(),
                name: s.judul.clone(),
                ago: format!("Panduan · langkah {} dari {n}", i + 1),
                caption: s.teks.clone(),
                filter: "normal",
                link: if is_safe_url(&s.tautan) { s.tautan.clone() } else { String::new() },
                cta: s.tombol.clone(),
            })
            .collect();
        let json = serde_json::to_string(&data).unwrap_or_else(|_| "[]".into()).replace("</", "<\\/");
        view! {
            <section class="pd-stories" aria-label="Panduan memesan undangan" data-story-slug="_panduan">
                <div class="pd-stories__head">
                    <p class="pd-stories__label"><span>"Cara Pesan"</span>{format!("{n} langkah mudah")}</p>
                    <button type="button" class="pd-stories__all" data-story-open="0" data-story-src="panduan-data">"Putar panduan"<Icon name="play_arrow" /></button>
                </div>
                <div class="story-bar pd-stories__bar" style=format!("--n:{n}")>
                    {items.into_iter().enumerate().map(|(i, s)| view! {
                        <div class="story-item">
                            <button type="button" class="story-user-btn" data-story-open=i.to_string() data-story-src="panduan-data"
                                data-story-id=s.id.to_string() aria-label=format!("Panduan langkah {}: {}", i + 1, s.judul)>
                                <span class="story-avatar-ring">
                                    <img class="story-avatar-img" src=s.img.clone() alt="" loading="lazy" decoding="async" />
                                    <b class="pd-stories__no" aria-hidden="true">{(i + 1).to_string()}</b>
                                </span>
                                <span class="story-username">{s.judul.clone()}</span>
                            </button>
                        </div>
                    }).collect_view()}
                </div>
                // data-fit=contain: gambar panduan berisi teks → tampil utuh (tak dipangkas
                // sisi seperti foto), sisa layar = warna latar gambar.
                <script type="application/json" id="panduan-data" data-seg="1" data-fit="contain" inner_html=json></script>
            </section>
        }
    })
}

/// Carousel banner beranda: geser (scroll-snap, bisa diusap tanpa JS), titik &
/// tombol ‹ ›; berganti otomatis tiap 6 detik lewat skrip global (app.rs,
/// `[data-banner]`) — berhenti saat disentuh/di-hover & bila "kurangi animasi".
#[component]
fn BannerCarousel(items: Vec<crate::web::model::Banner>) -> impl IntoView {
    use crate::web::skin::is_safe_url;
    // Server sudah menyaring aktif & jadwal; saring URL sekali lagi.
    let items: Vec<_> = items.into_iter().filter(|b| is_safe_url(&b.img)).collect();
    let n = items.len();
    (n > 0).then(|| {
        view! {
            <section class="bn" data-banner="" aria-roledescription="carousel" aria-label="Promo">
                <div class="bn__track" data-banner-track="">
                    {items.into_iter().enumerate().map(|(i, b)| {
                        let hp = if is_safe_url(&b.img_hp) { b.img_hp.clone() } else { b.img.clone() };
                        // Tautan: path situs atau URL http(s) saja.
                        let link = Some(b.link.trim().to_string()).filter(|l| is_safe_url(l));
                        let first = i == 0;
                        view! {
                            <div class="bn__slide" role="group" aria-roledescription="slide" aria-label=format!("{} dari {n}", i + 1)>
                                <picture>
                                    <source media="(max-width: 720px)" srcset=hp />
                                    <img src=b.img.clone() alt="" decoding="async" loading=if first { "eager" } else { "lazy" } fetchpriority=if first { "high" } else { "auto" } />
                                </picture>
                                {link.clone().map(|l| view! { <a class="bn__hit" href=l aria-label=b.judul.clone() tabindex="-1"></a> })}
                                {(!b.judul.is_empty() || !b.sub.is_empty()).then(|| view! {
                                    <div class="bn__text">
                                        {(!b.judul.is_empty()).then(|| view! { <h2>{b.judul.clone()}</h2> })}
                                        {(!b.sub.is_empty()).then(|| view! { <p>{b.sub.clone()}</p> })}
                                        {link.clone().filter(|_| !b.cta.is_empty()).map(|l| view! {
                                            <a class="btn btn--gold bn__cta" href=l>{b.cta.clone()}<Icon name="arrow_forward" /></a>
                                        })}
                                    </div>
                                })}
                            </div>
                        }
                    }).collect_view()}
                </div>
                {(n > 1).then(|| view! {
                    <button type="button" class="bn__nav bn__nav--prev" data-banner-prev="" aria-label="Banner sebelumnya"><Icon name="chevron_left" /></button>
                    <button type="button" class="bn__nav bn__nav--next" data-banner-next="" aria-label="Banner berikutnya"><Icon name="chevron_right" /></button>
                    <div class="bn__dots">
                        {(0..n).map(|i| view! {
                            <button type="button" class="bn__dot" class:is-on=i == 0 data-banner-dot=i.to_string() aria-label=format!("Banner {}", i + 1)></button>
                        }).collect_view()}
                    </div>
                })}
            </section>
        }
    })
}


/// Konten SEO beranda (dirender di server, di luar Suspense katalog): apa itu
/// undangan online, fitur, cara membuat, FAQ + data terstruktur Service &
/// FAQPage. Teks FAQ = isi JSON-LD (Google mewajibkan sama dengan yang tampil).
#[component]
fn UndanganOnlineInfo() -> impl IntoView {
    view! { <super::layanan::WithKonten view=undangan_online_info /> }
}

fn faq_items(k: &Konten) -> Vec<(&'static str, String)> {
    let mut paket: Vec<String> = k.paket.iter().filter(|p| p.price > 0).map(|p| format!("{} {}", p.name, rupiah(p.price))).collect();
    paket.truncate(4);
    let harga = if paket.is_empty() {
        "Sekali bayar tanpa biaya langganan — lihat halaman Paket & Harga.".to_string()
    } else {
        format!("Mulai {} sekali bayar tanpa biaya langganan: {}. Semua tema bisa dipakai di paket mana pun.", rupiah(k.min_price()), paket.join(", "))
    };
    vec![
        ("Apa itu undangan online?", "Undangan online (undangan digital atau undangan website) adalah undangan pernikahan berbentuk halaman web yang dibagikan lewat tautan WhatsApp. Tamu bisa melihat detail akad & resepsi, peta lokasi, galeri foto, memutar musik, mengisi RSVP, dan mengirim doa langsung dari HP.".into()),
        ("Berapa harga undangan online di ilyvowcraft?", harga),
        ("Berapa lama membuat undangan online?", "Sekitar 5 menit: pilih tema, isi data mempelai dan acara, unggah foto serta lagu, lalu lihat pratinjaunya.".into()),
        ("Apakah bisa dicoba gratis sebelum membayar?", "Bisa. Undangan dapat Anda pratinjau gratis; pembayaran dilakukan saat undangan sudah siap disebar ke tamu.".into()),
        ("Fitur apa saja yang ada di undangan online ini?", "RSVP dan ucapan doa, buku tamu dengan QR check-in, amplop digital (nomor rekening), musik latar, galeri foto, hitung mundur, peta Google Maps, nama tamu personal di setiap tautan, serta animasi pembuka premium.".into()),
        ("Apakah tersedia tema undangan adat Jawa dan daerah lain?", "Tersedia tema adat Nusantara — Jawa (wayang kulit, gebyok keraton), Minang, Bali, Sunda, Batak, Bugis, dan Dayak — serta tema botanical dan modern.".into()),
    ]
}

/// Direktori semua tema per budaya/nuansa — tautan HTML biasa ke halaman
/// demo tiap tema, jadi Google merayapi seluruh halaman tema dari beranda
/// (kartu katalog dibatasi 24 & etalase menaut ke demo /u yang noindex).
#[component]
fn DirektoriTema(themes: Vec<ThemeInfo>) -> impl IntoView {
    let mut grup: Vec<(String, Vec<ThemeInfo>)> = Vec::new();
    for t in themes {
        let label = if t.nuansa.trim().is_empty() { t.category.trim().to_string() } else { t.nuansa.trim().to_string() };
        match grup.iter_mut().find(|g| g.0 == label) {
            Some(g) => g.1.push(t),
            None => grup.push((label, vec![t])),
        }
    }
    grup.sort_by(|a, b| b.1.len().cmp(&a.1.len()).then_with(|| a.0.cmp(&b.0)));
    view! {
        <section class="direktori" aria-labelledby="direktori-judul">
            <Bab no="05" label="Semua Tema" />
            <h2 id="direktori-judul">"Tema Undangan Online per "<em>"Budaya"</em></h2>
            <div class="direktori__grid">
                {grup.into_iter().map(|(label, list)| view! {
                    <div class="direktori__grup">
                        <h3>{format!("Undangan Online {label}")}</h3>
                        <ul>
                            {list.into_iter().map(|t| view! {
                                <li><a href=format!("/tema/{}", t.slug) title=format!("Undangan online tema {}", t.name)>{t.name.clone()}</a></li>
                            }).collect_view()}
                        </ul>
                    </div>
                }).collect_view()}
            </div>
        </section>
    }
}

/// Label bagian bernomor bergaya editorial: `01 / FITUR ……… 01`.
#[component]
fn Bab(no: &'static str, label: &'static str) -> impl IntoView {
    view! { <p class="bab"><span>{format!("{no} / {label}")}</span><span aria-hidden="true">{no}</span></p> }
}

fn undangan_online_info(k: Konten) -> impl IntoView {
    let faqs = faq_items(&k);
    let prices: Vec<i64> = k.paket.iter().map(|p| p.price).collect();
    let ld_faq = seo::faq(&faqs);
    const FITUR: &[(&str, &str, &str)] = &[
        ("how_to_reg", "RSVP & Ucapan Doa", "Tamu konfirmasi kehadiran dan menulis doa restu; rekapnya langsung tampil di dasbor Anda."),
        ("qr_code_2", "Buku Tamu & QR Check-in", "Setiap tamu punya QR; scan di pintu masuk untuk buku tamu digital yang rapi."),
        ("account_balance_wallet", "Amplop Digital", "Cantumkan rekening atau dompet digital dengan tombol salin sekali sentuh."),
        ("library_music", "Musik Latar & Galeri", "Putar lagu favorit dan tampilkan foto prewedding terbaik Anda."),
        ("person", "Nama Tamu Personal", "Satu tautan per tamu — nama mereka tertulis di sampul undangan."),
        ("auto_awesome", "Animasi Pembuka Premium", "Pintu gebyok, gapura, hingga pagelaran wayang yang membuka undangan dengan anggun."),
    ];
    view! {
        <JsonLd data=seo::service(&prices) />
        <JsonLd data=ld_faq />
        <section class="seo-info" aria-labelledby="seo-info-title">
            <div class="seo-info__intro">
                <Bab no="01" label="Undangan Digital" />
                <h2 id="seo-info-title">"Undangan Online Pernikahan yang "<em>"Elegan"</em>", Cepat & Mudah Dibagikan"</h2>
                <p>
                    {crate::brand!()}" adalah layanan undangan online pernikahan — dikenal juga sebagai undangan digital atau undangan website — "
                    "dengan tema adat Nusantara dan desain premium. Cukup kirim satu tautan lewat WhatsApp, tamu langsung melihat detail akad & resepsi, "
                    "lokasi Google Maps, galeri foto, dan mengisi RSVP dari HP. Hemat biaya cetak, ramah lingkungan, dan bisa diperbarui kapan saja."
                </p>
                <p>
                    "Berbeda dari undangan nikah cetak, undangan pernikahan digital tak pernah salah alamat dan tak perlu diantar satu per satu: "
                    "nama setiap tamu tertulis otomatis di sampul, perubahan jam atau lokasi langsung sampai ke semua tamu, dan buku tamu terisi "
                    "sendiri lewat QR. Anda bisa mencoba seluruh tema undangan online secara gratis dan baru membayar ketika undangan siap disebar."
                </p>
            </div>
            <Bab no="02" label="Fitur di Setiap Paket" />
            <div class="seo-info__grid">
                {FITUR.iter().enumerate().map(|(i, (ic, t, d))| view! {
                    <article class="seo-info__card">
                        <p class="seo-info__no"><Icon name=ic /><span>{format!("{:02}", i + 1)}</span></p>
                        <h3>{*t}</h3>
                        <p>{*d}</p>
                    </article>
                }).collect_view()}
            </div>
            <div class="seo-info__steps">
                <Bab no="03" label="Cara Pesan" />
                <h2>"Cara Membuat Undangan "<em>"Online"</em></h2>
                <ol>
                    <li><b>"Pilih tema"</b>" dari "<a href="/#katalog">"katalog tema undangan"</a>" — adat Jawa, Minang, Bali, hingga modern."</li>
                    <li><b>"Isi data"</b>" mempelai, akad & resepsi, lalu unggah foto dan lagu."</li>
                    <li><b>"Pratinjau gratis"</b>" dan sempurnakan sampai sesuai keinginan."</li>
                    <li><b>"Bayar & sebar"</b>" tautan bernama tamu lewat WhatsApp — lihat "<a href="/paket">"paket & harga"</a>"."</li>
                </ol>
                <a class="btn btn--primary" href="/buat"><Icon name="edit" />"Buat Undangan Online Sekarang"</a>
            </div>
            <div class="seo-info__faq">
                <Bab no="04" label="Tanya Jawab" />
                <h2>"Pertanyaan Seputar Undangan Online"</h2>
                {faqs.into_iter().map(|(q, a)| view! {
                    <details class="seo-faq card">
                        <summary>{q}</summary>
                        <p>{a}</p>
                    </details>
                }).collect_view()}
                <p class="muted small">"Masih ada pertanyaan? Baca "<a href="/panduan">"panduan lengkap"</a>" atau coba "<a href=format!("/u/{}", crate::web::themes::DEMO_SLUG)>"contoh undangan online"</a>"."</p>
            </div>
            // Penutup ala halaman produk editorial: satu kalimat besar + dua aksi.
            <div class="seo-info__cta">
                <p class="seo-info__meta">"Pratinjau gratis · Bayar saat siap · Tanpa aplikasi"</p>
                <h2>"Mulai "<em>"merangkai"</em>" undanganmu."</h2>
                <p class="muted">"Pilih tema, isi data, dan lihat hasilnya langsung — bayar hanya setelah kamu puas."</p>
                <div class="seo-info__btns">
                    <a class="btn btn--primary" href="/buat"><Icon name="edit" />"Buat Undangan"</a>
                    <a class="btn btn--outline" href=format!("/u/{}", crate::web::themes::DEMO_SLUG)>"Lihat Contoh"</a>
                </div>
            </div>
        </section>
    }
}
